/*
 * UIX Library.
 * @author terangel
 */

var uix = {

    /**
     * TODO: Documentar...
     */
    ready: function(callback) {
        if (document.readyState !== 'loading') {
            callback();
        } else {
            document.addEventListener('DOMContentLoaded', callback);
        }
    },

    /**
     * Carga de ficheros externos: scripts, hojas de estilo y demás.
     * @param {{type: string, href: string}[]} files Ficheros a cargar.
     * @param {function} Función de retorno que se llamará al completar la carga de todos los ficheros.
     */
    require: function(files, callback) {
        var head = document.getElementById('head')[0],
            count = files.length,
            check = function() {
                count--;
                if (count === 0) {
                    callback();
                }
            };
        for (var i = 0, e; i < files.length; i++) {
            if (files.type === 'script') {
                e = document.createElement('script');
                e.type = 'text/javascript';
                e.src = href;
            } else {
                e = document.createElement('link');
                e.type = 'text/css';
                e.rel = 'stylesheet';
                e.href = href;
            }
            e.onload = check;
            head.appendChild(e);
        }
    },

    // Utility Functions
    // -----------------------------------------------------------------------------------------------------------------
    /**
     * Implementación de la función forEach para cualquier objeto con estructura de Array, aunque no lo sea.
     * @param {*[]} array Objeto tipo Array especificado.
     * @param {function(value: *, index: number, array: Object)} callback Función de iteración.
     * @param {Object} scope Objeto "this".
     */
    forEach: function(array, callback, scope) {
        for (var i = 0; i < array.length; i++) {
            callback.call(scope, array[i], i);
        }
    },

    // AJAX
    // -----------------------------------------------------------------------------------------------------------------
    /**
     * Simplifica el envío de peticiones HTTP a través del objeto XMLHttpRequest.
     * @param {string} url Dirección URL especificada.
     * @param {Object|function} options Opciones y ajustes adicionales.
     * @param {string} [options.method] Método HTTP a emplear.
     * @param {Object} [options.data] Datos a enviar.
     * @param {Object} [options.headers] Cabeceras a enviar.
     * @param {boolean} [options.json] Indica si enviar los datos en formato JSON.
     * @param {number} [options.timeout] Tiempo máximo para procesar la petición.
     * @param {function(err: ?Error, data: ?Object, xhr: XMLHttpRequest)} [options.complete] Función de retorno.
     * @param {function(err: ?Error, data: ?Object, xhr: XMLHttpRequest)} [complete] Función de retorno.
     * @return {XMLHttpRequest} Objeto de petición creado.
     */
    load: function(url, options, complete) {
        var defaults = {
            method: 'GET'
        };
        if (typeof(options) === 'function') {
            complete = options;
            options = defaults;
        } else if (options) {
            options.method = options.method || (options.data ? 'POST' : 'GET');
            if (!complete) {
                complete = options.complete;
            }
        } else {
            options = defaults;
        }
        // Parámetros de consulta (query)
        if (options.data && options.method === 'GET') {
            var parts = URL.parse(url, true);
            Object.extend(parts.query, options.data)
            url = URL.format(parts);
        }
        // Antes de realizar la petición comprobamos si hay conexión a internet.
        // TODO: Evaluar si dejarlo aquí o subirlo arriba del todo.
        if (!uix.checkConnection(complete)) {
            return;
        }
        // Se incializa la petición
        var xhr = new XMLHttpRequest();
        xhr.open(options.method, url, true);
        // Cabeceras de petición añadidas
        if (options.headers) {
            for (var key in options.headers) {
                xhr.setRequestHeader(key, options.headers[key]);
            }
        }
        // Envío de datos
        var data = null;
        if (options.data && options.method !== 'GET') {
            if (options.data instanceof FormData) {
                data = options.data;
            } else if (options.json) {
                xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
                data = JSON.stringify(options.data);
            } else {
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
                data = URL.formatQuery(options.data);
            }
        }
        // Manejo de eventos
        xhr.addEventListener('load', function() {
            var data = null,
                type = xhr.getResponseHeader('Content-Type');
            if (uix.isJSON(type)) {
                try {
                    data = JSON.parse(xhr.responseText);
                } catch (err) { // SyntaxError
                    return complete(err, null, xhr);
                }
            } else {
                data = xhr.responseText;
            }
            if (xhr.status >= 200 && xhr.status < 300 || xhr.status === 304) {
                complete(null, data, xhr);
            } else {
                var err = new Error('Unable to load \'' + url + '\': ' + xhr.statusText + ' (' + xhr.status + ')');
                err.status = xhr.status;
                complete(err, data, xhr);
            }
        }, false);
        xhr.addEventListener('error', function() {
            complete(new Error('Unable to load \'' + url + '\'.'), null, xhr);
        }, false);
        // Timeout por defecto (15 sg)
        xhr.timeout = (options.timeout === undefined) ? 15000 : options.timeout;
        xhr.ontimeout = function() {
            complete(new Error('Timeout loading \'' + url + '\'.'), null, xhr);
        }
        // Se envía la petición
        xhr.send(data);
        // Se devuelve el objeto de petición creado
        return xhr;
    },

    /**
     * Comprueba si hay conexión a internet. Si se especifica una función de retorno genera un error de conexión
     * (ConnectionError) pasándoselo a la función. Esto simplifica el tratamiento en muchos casos.
     * @param {function(err: ?Error)} [callback] Función de retorno.
     * @return {boolean} Devuelve verdadero si hay conexión o falso en caso contrario.
     */
    checkConnection: function(callback) {
        if (navigator.connection && navigator.connection.type === 'none') {
            if (callback) {
                callback(new ConnectionError());
            }
            return false;
        }
        return true;
    },

    /**
     * Comprueba si el tipo MIME especificado es de tipo JSON.
     * @param {string} mime
     * @return {boolean}
     */
    isJSON: function(type) {
        return /[\/+]json\b/.test(type);
    },

    // DOM
    // -----------------------------------------------------------------------------------------------------------------
    /**
     * Crea un nuevo elemento del tipo, atributos y contenido especificado.
     * @param {string} type Tipo o nombre de etiqueta.
     * @param {?Object} attribs Atributos a añadir en el nuevo elemento.
     * @param {string|Node|HTMLCollection|NodeList|Node[]|*[]} [content] Contenido del elemento, puede ser de cualquier
     * tipo. Desde cadenas de texto, colecciones de nodos, fragmentos de documento, etc.
     * @param {Object} [events] Tratamiento de eventos a añadir.
     * @return {Element} Devuelve el elemento creado.
     */
    create: function(type, attribs, content, events) {
        var el = document.createElement(type);
        if (attribs) {
            for (var name in attribs) {
                el.setAttribute(name, attribs[name]);
            }
        }
        if (content) {
            if (uix.isArrayLike(content)) {
                for (var i = 0; i < content.length; i++) {
                    el.appendChild(content[i] instanceof Node ? content[i] : document.createTextNode(content[i]));
                }
            } else if (content instanceof Node) {
                el.appendChild(content);
            } else {
                el.innerHTML = content;
            }
        }
        if (events) {
            for (var name in events) {
                el.addEventListener(name, events[name]);
            }
        }
        return el;
    },

    // Classes
    // -----------------------------------------------------------------------------------------------------------------
    /**
     * Añade uno o varios nombres de clases en el elemento especificado.
     * @param {Element} el Elemento especificado.
     * @param {string|string[]} name Nombre de una o varias clases de estilo.
     * @return {Element} Devuelve el elemento especificado.
     */
    addClass: function(el, name) {
        if (el) {
            if (Array.isArray(name)) {
                for (var i = 0; i < name.length; i++) {
                    el.classList.add(name[i]);
                }
            } else {
                el.classList.add(name);
            }
        }
        return el;
    },

    /**
     * Elimina uno o varios nombres de clases del elemento especificado.
     * @param {Element} el Elemento especificado.
     * @param {string|string[]|function(name: string)} name Nombre de una o varias clases de estilo.
     * Si se especifica una función se le pasa cada una de las clases añadidas eliminándose aquellas para las que la
     * función devuelve verdadero.
     * @return {Element} Devuelve el elemento especificado.
     */
    removeClass: function(el, name) {
        if (el) {
            if (typeof(name) === 'function') {
                var filter = name;
                for (var i = el.classList.length - 1; i >= 0; i--) {
                    if (filter(name = el.classList.item(i))) {
                        el.classList.remove(name);
                    }
                }
            } else if (Array.isArray(name)) {
                for (var i = 0; i < name.length; i++) {
                    el.classList.remove(name[i]);
                }
            } else {
                el.classList.remove(name);
            }
        }
        return el;
    },

    /**
     * Añade o elimina uno o varios nombres de clases del elemento especificado.
     * @param {Element} el Elemento especificado.
     * @param {string|string[]} name Nombre de una o varias clases.
     * @param {boolean} [force] Indica si añadir o eliminar la clase o clases especificadas.
     * @return {Element} Devuelve el elemento especificado.
     */
    toggleClass: function(el, name, force) {
        if (el) {
            /**
             * Polyfill de la función Element.classList.toggle() por falta de compatibilidad, por ejemplo en iOS 9.
             * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/Element/classList}
             */
            function t(n, f) {
                return (el.classList[(f = (f === undefined) ? !el.classList.contains(n) : f) ? 'add' : 'remove'](n), f);
            }
            if (Array.isArray(name)) {
                for (var i = 0; i < name.length; i++) {
                    t(name[i], force);
                }
            } else {
                t(name, force);
            }
        }
        return el;
    },

    /**
     * Comprueba si un nombre de clase está añadido en el elemento especificado.
     * @param {Element} el Elemento especificado.
     * @param {string} name Nombre de clase especificado.
     * @return {boolean} Devuelve verdadero si el nombre está añadido y falso en caso contrario.
     */
    hasClass: function(el, name) {
        return el.classList.contains(name);
    },

    /**
     * Devuelve la parte final del nombre de la primera clase añadida que empiece por el prefijo especificado.
     * @param {Element} el Elemento especificado.
     * @param {string} prefix Prefijo especificado.
     * @return {string=} Devuelve la cadena resultante o nulo si no se encuentra ninguna clase.
     */
    getClassEnding: function(el, prefix) {
        for (var i = 0, name; i < el.classList.length; i++) {
            if ((name = el.classList.item(i)).startsWith(prefix)) {
                return name.substr(prefix.length);
            }
        }
        return null;
    },

    // Traversing
    // -----------------------------------------------------------------------------------------------------------------
    /**
     * Devuelve el primer hijo directo del elemento especificado que cumpla el selector.
     * @param {Element} el Elemento especificado.
     * @param {string} selector Selector especificado.
     */
    child: function (el, selector) {
        for (el = el.firstElementChild; el !== null; el = el.nextElementSibling) {
            if (uix.matches(el, selector)) {
                return el;
            }
        }
        return null;
    },

    /**
     * TODO: Documentar...
     */
    lastChild: function(el, selector) {
        for (el = el.lastElementChild; el !== null; el = el.previousElementSibling) {
            if (uix.matches(el, selector)) {
                return el;
            }
        }
        return null;
    },

    /**
     * TODO: Documentar...
     */
    children: function (el, selector) {
        var children = [];
        for (el = el.firstElementChild; el !== null; el = el.nextElementSibling) {
            if (!selector || uix.matches(el, selector)) {
                children.push(el);
            }
        }
        return children;
    },

    // Siblings --------------------------------------------------------------------------------------------------------
    /**
     * TODO: Documentar...
     */
    siblings: function (e, selector) {
        var siblings = [];
        e = e.parentNode.firstChild;
        do {
            if (!selector || uix.matches(e, selector)) {
                siblings.push(e);
            }
        } while (e = e.nextSibling);
        return siblings;
    },

    /**
     * TODO: Documentar...
     */
    firstSibling: function (e, selector) {
        e = e.parentNode.firstChild;
        do {
            if (!selector || uix.matches(e, selector)) {
                return e;
            }
        } while (e = e.nextSibling);
        return null;
    },

    /**
     * TODO: Documentar...
     */
    lastSibling: function (e, selector) {
        e = e.parentNode.lastChild;
        do {
            if (!selector || uix.matches(e, selector)) {
                return e;
            }
        } while (e = e.previousSibling);
        return null;
    },

    /**
     * TODO: Documentar...
     */
    nextAllSiblings: function (e, selector) {
        var siblings = [];
        while (e = e.nextSibling) {
            if (!selector || uix.matches(e, selector)) {
                siblings.push(e);
            }
        }
        return siblings;
    },

    /**
     * TODO: Documentar...
     */
    prevAllSiblings: function (e, selector) {
        var siblings = [];
        while (e = e.previousSibling) {
            if (!selector || uix.matches(e, selector)) {
                siblings.push(e);
            }
        }
        return siblings;
    },

    /**
     * TODO: Documentar...
     */
    nextSibling: function (e, selector) {
        while (e = e.nextSibling) {
            if (!selector || uix.matches(e, selector)) {
                return e;
            }
        }
        return null;
    },

    /**
     * TODO: Documentar...
     */
    prevSibling: function (e, selector) {
        var siblings = [];
        while (e = e.previousSibling) {
            if (!selector || uix.matches(e, selector)) {
                return e;
            }
        }
        return null;
    },

    /**
     * TODO: Documentar...
     */
    insertAfter: function(node, prev) {
        prev.parentNode.insertBefore(node, prev.nextSibling);
    },

    // -----------------------------------------------------------------------------------------------------------------
    /**
     * TODO: Documentar...
     */
    matches: function (el, selector) {
        return (el.matches ||
                el.matchesSelector ||
                el.mozMatchesSelector ||
                el.msMatchesSelector ||
                el.oMatchesSelector ||
                el.webkitMatchesSelector ||
                function (selector) {
                    var nodes = (el.parentNode || el.document || el.ownerDocument).querySelectorAll(selector),
                        i = -1;
                    while (nodes[++i] && nodes[i] !== el);
                    return !!nodes[i];
                }
            ).call(el, selector);
    },

    /**
     * Devuelve un array con los elementos antecesores del elemento especificado, y opcionalmente filtrando por un
     * selector y hasta un elemento contenedor especificado.
     * @param {Element} el Elemento especificado.
     * @param {string|Element} Selector opcional o elemento contenedor.
     * @param {Element} Elemento contenedor (no se incluye en el array).
     * @return {Element[]} Array de elementos padre o antecesores.
     */
    parents: function(el, selector, container) {
        if (selector instanceof Element) {
            container = selector;
            selector = null;
        }
        var els = [];
        while ((el = el.parentNode) !== null && el !== container) {
            if (!selector || this.matches(el, selector)) {
                els.push(el);
            }
        }
        return els;
    },

    /**
     * TODO: Documentar...
     */
    closest: function(el, selector, context) {
        do {
            if (this.matches(el, selector)) {
                return el;
            }
        } while ((el = el.parentElement) && el !== context);
        return null;
    },


    /**
     * Elimina el elemento o elementos especificados.
     * @param {Element|Element[]|NodeList} Element o elementos especificados.
     */
    remove: function(el) {
        if (el instanceof NodeList) { // NOTE: También podríamos usar: uix.isArrayLike(el)
            for (var i = el.length - 1; i >= 0; i--) {
                el[i].parentNode.removeChild(el[i]);
            }
        } else {
            el.parentNode.removeChild(el);
        }
    },

    /**
     * TODO: Documentar...
     */
    empty: function(el) {
        while (el.firstChild) {
            el.removeChild(el.firstChild);
        }
    },

    /**
     * Comprueba si el objeto especificado es un array o tiene estructura de array como NodeList o HTMLCollection.
     * @param {Object} obj Objeto especificado.
     * @return {boolean}
     */
    isArrayLike: function(obj) {
        return Array.isArray(obj) || obj instanceof NodeList || obj instanceof HTMLCollection;
        // NOTE: Otra alternativa:
        // (['[object HTMLCollection]', '[object NodeList]'].indexOf(Object.prototype.toString.call(obj)) !== -1)
    },

    // Visualization ---------------------------------------------------------------------------------------------------
    hide: function(e, time, complete) {
        TweenMax.to(e, time, {
            autoAlpha: 0,
            onComplete: function() {
                e.style.display = 'none';
                if (complete && typeof(complete) === 'function') {
                    complete();
                }
            }
        });
    },

    show: function(e, time, complete) {
        e.style.display = '';  // TODO: Falta el REFLOW
        TweenMax.to(e, time, {
            autoAlpha: 1,
            onComplete: function () {
                if (complete && typeof(complete) === 'function') {
                    complete();
                }
            }
        });
    },

    /**
     * Oculta o visualiza el elemento especificado.
     * @param {HTMLElement} el Elemento especificado.
     * @param {(boolean|Object)} [show] Indica si mostrar u ocultar el elemento. Si no se especifica se altera la
     * visibilidad del elemento. Como alternativa se puede especificar las opciones adicionales siguientes.
     * @param {Object} [options] Opciones adicionales.
     * @param {boolean} [options.show] Indica si mostrar u ocultar el elemento.
     * @param {string} [options.transition] Nombre de transición a realizar. Si es 'none' se elimina la posible
     * transición definida por clase en el elemento.
     * @param {number} [options.duration] Duración de la transición en segundos.
     * @param {boolean} [options.reverse] Indica si invertir el sentido de la transición.
     * @param {function} [options.done] Función que se llamará al finalizar la transición.
     * @param {boolean} [options.remove] Indica si eliminar el elemento al ocultarlo.
     * @param {function} [options.displayNone] Como alternativa programática a la clase '--display-none', indica si
     * poner el 'display' a 'none' al ocultar el elemento.
     * @return {boolean} Devuelve verdadero si hay cambio de estado o falso en caso contrario.
     */
    toggle: function(el, show, options) {
        if (typeof show === 'object') {
            options = show;
            show = null;
        }
        options = options || {};
        if (show == null) {
            show = options.show;
        }
        // Elimina el tratamiento del evento "transitionend" al finalizar la transición o al interrumpir una transición
        // en proceso.
        function clear() {
            var handler = uix.getState(el, 'toggleEndHandler');
            if (handler) {
                el.removeEventListener('transitionend', handler, false);
                uix.clearState(el, 'toggleEndHandler');
            }
        }
        // Finaliza la transición eliminando el elemento o poniendo su propiedad "display" a "none" cuando corresponda,
        // tras lo cual elimina el tratamiento del evento "transitionend" si ha sido añadido y notifica el final de la
        // transición llamando a la función "done" (callback) si se ha especificado.
        function done() {
            if (!show) {
                if (options.remove) {
                    uix.remove(el);
                } else if (options.displayNone || uix.hasClass(el, '--display-none')) {
                    el.style.display = 'none';
                }
            }
            clear();
            if (options.done) {
                options.done();
            }
        }
        // Se limpia el estado inicialmente.
        clear();
        // Se comprueba el estado actual y si realizar o no la transición.
        var hidden = el.classList.contains('uix-hide');
        if (show == null) {
            show = hidden;
        } else if (show === !hidden) {
            done();
            return false;
        }
        // Se comprueba si se ha especificado transición en opciones o como atributo de datos.
        var trans = options.transition || el.dataset.transition,
            transClass = uix.getClassEnding(el, 'uix-transition-');
        if (trans !== transClass) {
            if (transClass) {
                uix.removeClass(el, 'uix-transition-' + transClass);
            }
            if (trans && trans !== 'none') {
                uix.addClass(el, 'uix-transition-' + trans);
            }
        }
        // NOTE: La inversión de la transición solo se puede especificar programáticamente por opciones cada vez, en
        // otros casos se eliminará la clase si está añadida.
        uix.toggleClass(el, 'uix-reverse', !!options.reverse);
        // Se modifica la duración de la transición si se ha especificado en opciones.
        el.style.transitionDuration = (options.duration) ? options.duration + 's' : '';
        // En caso de visualizar el elemento se comprueba si la propiedad "display" es "none".
        if (show && el.style.display === 'none') {
            el.style.display = '';
            // Forzamos el REFLOW
            el.offsetHeight + el.offsetWidth;
        }
        // Si se ha definido o especificado transición comprobamos si realmente esta se va a producir para la
        // propiedad "visibility" y por tanto podemos esperar el evento "transitionend" o no.
        if (trans && trans !== 'none') {
            var cs = window.getComputedStyle(el, null);
            // En primer lugar comprobamos que la propiedad "visibility" esté dentro de la transición y en segundo que
            // se vaya a producir cambio de valor, de "visible" a "hidden" o de "hidden" a "visible", condición
            // indispensable para que recibamos el evento "transitionend".
            if (!/(^|,\s*)(all|visibility)(,|$)/i.test(cs.getPropertyValue('transition-property')) ||
                    cs.getPropertyValue('visibility') === (show ? 'visible' : 'hidden')) {
                trans = null;
            }
        }
        // Se añade o elimina la clase "uix-hide" para llevar a cabo la transición.
        uix.toggleClass(el, 'uix-hide', !show);
        // Si preveemos que se va a producir la transición sobre la propiedad "visibility" añadimos el tratamiento del
        // evento "transitionend", si no pues no.
        if (trans && trans !== 'none') {
            el.addEventListener('transitionend', uix.putState(el, 'toggleEndHandler', function(event) {
                if (event.propertyName === 'visibility') {
                    done();
                }
            }), false);
        } else {
            // En cualquier otro caso damos por finalizada la transición aunque en algunas circunstancias esta se
            // produzca, por ejemplo al visualizar un elemento en plena transición de ocultación sin haber concluido.
            done();
        }
        return true;
    },

    /**
     * Evalua si el elemento especificado está visible o no.
     * @param {Element} el Elemento especificado.
     * @return {boolean} Devuelve verdadero si está visible o falso en caso contrario.
     */
    isVisible: function(el) {
        return !uix.hasClass(el, 'uix-hide');
    },

    /**
     * Devuelve la duración mayor en milisegundos de la transición definida incluyendo el delay inicial.
     * @param {Element} el Elemento especificado.
     * @return {number} Duración en milisegundos o 0 si no está definida.
     */
    getTransitionTimeout: function(el) {
        var timeout = 0;
        var cs = window.getComputedStyle(el, null);
        var delays = cs.transitionDelay.split(',');
        for (var i = 0; i < delays.length; i++) {
            delays[i] = uix.parseTime(delays[i]);
        }
        var durations = cs.transitionDuration.split(',');
        for (var i = 0, d; i < durations.length; i++) {
            var d = uix.parseTime(durations[i]) + delays[i % delays.length];
            if (d > timeout) {
                timeout = d;
            }
        }
        return timeout;
    },

    /**
     * Parsea una cadena de tiempo o duración especificada en segundos o milisegundos, incluyendo siempre la unidad
     * (s/ms) y devuelve el número de milisegundos resultante.
     * @param {string} str Cadena especificada.
     * @return {number} Número de milisegundos.
     */
    parseTime: function(str) {
        var time = 0;
        var match = /([\d.]+)(s|ms)/i.exec(str);
        if (match) {
            time = parseFloat(match[1]);
            if (match[2] === 's') {
                time *= 1000;
            }
        }
        return time;
    },

    /**
     * Muestra el desplegable especificado controlando que al hacer click fuera del mismo se oculte.
     * @param {Element} dropdown Elemento que contiene el desplegable especificado.
     * @param {Event} evento Evento original.
     */
    toggleDropdown: function(el) {
        if (uix.hasClass(el, 'uix-hide')) {
            var close = function(event) {
                var targetEl = event.target;
                do {
                    if (targetEl === el) {
                        return;
                    }
                } while (targetEl = targetEl.parentElement);
                document.documentElement.removeEventListener('tap', close, true);
                uix.toggle(el, false);
            };
            document.documentElement.addEventListener('tap', close, true);
            uix.toggle(el, true);
        }






        // TODO: De momento pasamos el evento original como mecanismo para evitar que el mismo evento que causa la
        // visualización del desplegable no cause la ocultación inmediata, pero esto no funcionará cuando el evento que
        // desencadena la visualización no es del mismo tipo del que usamos para la ocultación.
        // Quizás la mejor opción es retrasar unos instances la adición del evento en el documento de forma que
        // cualquier evento tratado sea posterior al flujo de visualización.
        /*
        if (uix.hasClass(dropdown, 'hide')) {
            var doc = dropdown.ownerDocument,
                hide = function (ev) {
                    if (ev !== event) {
                        uix.toggle(dropdown, false);
                        doc.removeEventListener('click', hide, false);
                    }
                };
            uix.toggle(dropdown, true);
            doc.addEventListener('click', hide, false);

            // Corregimos la posición del desplegable si se sale de pantalla
            uix.fixPosition(dropdown, true);
        }
        */
    },

    /**
     * Añade o elimina el manejo de un evento cuando se produce fuera del elemento especificado.
     * @param {Element} el Elemento especificado.
     * @param {Function} callback Función de retorno, si es nulo se elimina el tratamiento actual.
     */
    clickout: function(el, name, callback) {
        var listener;
        var listenerName = name + 'OutsideListener'
        if (callback) {
            listener = function(event) {
                var target = event.target;
                do {
                    if (target === el) {
                        return;
                    }
                } while (target = target.parentElement);
                callback();
            };
            uix.putState(el, listenerName, listener);
            document.addEventListener(name, listener, true);
        } else if (listener = uix.getState(el, listenerName)) {
            document.removeEventListener(name, listener, true);
            uix.clearState(el, listenerName);
        }
    },

    // Styles ----------------------------------------------------------------------------------------------------------
    /**
     * Devuelve un objeto o array asociativo con las propiedades de estilo computadas del elemento especificado.
     * @param {Element} elem Elemento especificado.
     * @return {Object} Array asociativo con los nombres de propiedades en formato de definición (no Camel Case), y sus
     * correspondientes valores.
     */
    computeStyle: function(elem) {
        var styles = {},
            cs = document.defaultView.getComputedStyle(elem, null);
        for (var i = 0; i < cs.length; i++) {
            // NOTE: Filtramos todas las propiedades que contengan la cadena "-origin" ???
            // if (cs[i].indexOf("-origin") === -1) {
            styles[cs[i]] = cs.getPropertyValue(cs[i]);
            // }
        }
        return styles;
    },

    /**
     * Devuelve un array con los nombres de las propiedades de estilo contenidas en los objetos especificados y que
     * tengan valores diferentes.
     * @param {Object} s1 Objeto de propiedades 1.
     * @param {Object} s2 Objeto de propiedades 2.
     * @param {boolean} [clear] Indica si eliminar de los objetos especificados las propiedades que no cambian.
     * @return {Object} Array resultante.
     */
    stylesDiff: function(s1, s2, clear) {
        var diff = [];
        for (var k in s1) {
            if (s1[k] !== s2[k]) {
                diff.push(k);
            } else if (clear) {
                delete s1[k];
                delete s2[k];
            }
        }
        return diff;
    },

    /**
     * Devuelve las coordenadas: posición (top, left), dimensiones (width, height) y límites inferior y derecho (bottom,
     * right) del elemento con respecto al documento o al elemento contenedor especificado.
     * @param {Element} el Elemento especificado.
     * @param {Element} [parent] Elemento contenedor hasta donde ampliar el cálculo de coordenadas. Si no se especifica
     * serán relativas al documento (0, 0).
     * @return {{top: number, left: number, bottom: number, right: number, width: number, height: number}} Coordenadas
     * obtenidas.
     */
    offset: function(el, parent) {
        var rect = {
            top: el.offsetTop,
            left: el.offsetLeft,
            width: el.offsetWidth,
            height: el.offsetHeight
        }
        while ((el = el.offsetParent) && el !== parent) {
            rect.top += el.offsetTop;
            rect.left += el.offsetLeft;
        }

        // Añadimos los límites inferior y derecho
        rect.bottom = rect.top + rect.height;
        rect.right = rect.left + rect.width;

        return rect;
    },

    /**
     * Corrige la posición absoluta del elemento especificado si se sale de pantalla o de los límites del elemento padre
     * especificado.
     * @param {Element} el Elemento especificado.
     * @param {boolean} [clear] Indica si limpiar el ajuste realizado previamente.
     * @param {Element} [parent] Elemento padre especificado.
     */
    fixPosition: function(el, clear, parent) {
        if (clear) {
            el.style.top = '';
            el.style.left = '';
        }

        // Si se especifica un elemento contenedor se ajusta primero la posición con respecto al mismo y posteriormente
        // con respecto a la ventana
        var vw, vh,
            bounds, w, h,
            offset = {
                top: 0,
                left: 0
            };
        if (parent) {
            vw = parent.clientWidth;
            vh = parent.clientHeight;

            bounds = uix.offset(el, parent);
            if (el.offsetParent) {
                offset = uix.offset(el.offsetParent, parent);
            }
        } else {
            vw = window.innerWidth;
            vh = window.innerHeight;

            bounds = el.getBoundingClientRect();
            if (el.offsetParent) {
                offset = el.offsetParent.getBoundingClientRect();
            }
        }

        // Calculamos las dimensiones alto y ancho
        bounds.width = bounds.right - bounds.left;
        bounds.height = bounds.bottom - bounds.top;
        // NOTE: En la mayoría de los casos ya estarán incluidas en las coordenadas obtenidas, pero por si acaso las
        // calculamos aparte (puede ser el caso de Opera)

        if (bounds.top < 0) {
            el.style.top = 0;
        } else if (bounds.bottom > vh) {
            el.style.top = vh - bounds.height - offset.top + "px";
        }
        if (bounds.left < 0) {
            el.style.left = 0;
        } else if (bounds.right > vw) {
            el.style.left = vw - bounds.width - offset.left + "px";
        }

        // Si se ha especificado un elemento contenedor se realiza un segundo ajuste para ver si además se sale de
        // pantalla
        if (parent) {
            this.fixPosition(el, false);
        }
    },

    /**
     * Comprueba si hay intersección entre los dos elementos especificados.
     * @param {Element} e1 Primer elemento.
     * @param {Element} e2 Segundo elemento.
     * @return {boolean} Devuelve verdadero si hay intersección o falso en caso contrario.
     */
    intersect: function(e1, e2) {
        var r1 = e1.getBoundingClientRect(),
            r2 = e2.getBoundingClientRect();
        return (r2.left <= r1.right && r2.right >= r1.left && r2.top <= r1.bottom && r2.bottom >= r1.top);
    },

    // Almacenamiento de datos asociados a elementos del DOM -----------------------------------------------------------
    /**
     * Mapa de asignación de almacenamiento de datos o estado asociado a elementos del DOM por identificador.
     * @type {Object.<number, Object>}
     */
    _stateMap: {},

    /**
     * Siguiente identificador para vincular un elemento a un almacenamiento de datos.
     * @type {number}
     */
    _stateNextId: 1,

    /**
     * Guarda el estado especificado asociado al elemento.
     * @param {Element} el Elemento especificado.
     * @param {string|Object} name Nombre u objeto de datos a almacenar.
     * @param {*} value Datos a almacenar.
     * @return {*} Devuelve el valor o datos almacenados.
     */
    putState: function(el, name, value) {
        var id = el.dataset.stateId, state;
        if (id) {
            state = this._stateMap[id];
        } else {
            el.dataset.stateId = id = this._stateNextId++;
        }
        if (!state) {
            state = this._stateMap[id] = {};
        }
        if (typeof(name) === 'object') {
            Object.extend(state, name);
            return name;
        } else {
            return state[name] = value;
        }
    },

    /**
     * Devuelve el estado asociado a un elemento.
     * @param {Element} el Elemento especificado.
     * @param {string} [name] Nombre de variable a obtener. Si es nula o no se especifica devuelve el objeto de datos
     * asociado al completo y modificable.
     */
    getState: function(el, name) {
        var id = el.dataset.stateId, state;
        if (id && (state = this._stateMap[id])) {
            return (name) ? state[name] : state;
        }
        return null;
    },

    /**
     * Comprueba si el elemento contiene la variable de estado especificada.
     * @param {Element} el Elemento especificado.
     * @param {string} name Nombre de variable a obtener.
     */
    hasState: function(el, name) {
        var id = el.dataset.stateId, state;
        if (id && (state = this._stateMap[id])) {
            return name in state;
        }
        return false;
    },

    /**
     * Borra o elimina la variable especificada o en caso de omisión, el objeto de datos asociado al completo.
     * @param {Element} el Elemento especificado.
     * @param {string} [name] Nombre de variable a eliminar. Si es nula o no se especifica elimina el objeto de datos al
     * completo.
     * @return {*} Devuelve los datos eliminados o nulo si no se encuentran.
     */
    clearState: function(el, name) {
        var id = el.dataset.stateId, state, data = null;
        if (id && (state = this._stateMap[id])) {
            if (name) {
                data = state[name];
                delete state[name];
            } else {
                data = state;
                delete this._stateMap[id];
            }
        }
        return data;
    },

    // Loader ----------------------------------------------------------------------------------------------------------
    /**
     * Muestra u oculta el indicador de carga que primero se encuentre en el contexto especificado. Si no se especifica
     * ningún contexto se realiza la búsqueda desde la raíz del documento.
     * @param {boolean} show Indica si mostrar u ocultar el indicador.
     * @param {Object} [options] Opciones adicionales. (@see uix.toggle)
     * @param {Element} [options.loader] Referencia al elemento.
     * @param {Element} [options.context] Elemento donde buscar el indicador de carga.
     * @param {number} [options.delay=10] Tiempo de retardo (ms) en mostrar el indicador de carga.
     */
    toggleLoader: function(show, options) {
        // console.log('[' + performance.now().toFixed(3) + '] toggleLoader(' + show + ', ' + JSON.stringify(options) + ')');
        var loader = null,
            context = document,
            defaults = {};
        if (options) {
            options = Object.extend(defaults, options);
            if (options.loader) {
                loader = options.loader;
            } else if (options.context) {
                context = options.context;
            }
        } else {
            options = defaults;
        }
        if (!loader) {
            var s = '.uix-loader';
            if (context === document) {
                s = 'body > ' + s;
            }
            loader = context.querySelector(s);
        }
        if (loader) {
            uix.toggle(loader, show, options);
        }
        // TODO: Si no se encuentra podemos generar la estructura y añadirla al documento.
    },

    // Dialogs
    // -----------------------------------------------------------------------------------------------------------------
    /**
     * Abre una nueva vista de diálogo.
     * @param {string} name Nombre de la vista a abrir como diálogo.
     * @param {Object} [options] Opciones adicionales.
     * @param {Element} [options.container] Elemento contenedor donde añadir el diálogo.
     * @param {string('center'|'bottom')} [options.position] Posición del diálogo: center (default) o bottom.
     * @param {boolean} [options.fullscreen] Indica si mostrar el diálogo a pantalla completa, lo que evita que se añada
     * la capa de ocultación o oscurecimiento.
     * @param {string} [options.fragment] Indica la cadena a incluir como fragmento en la URL.
     * @param {boolean} [options.history] Indica si reemplazar la ruta actual del histórico (replace) o añadirla como
     * nueva entrada (por defecto).
     * @param {number} [options.delay] Tiempo de espera para mostrar el diálogo (milisegundos).
     * @param {function(view: View)} [options.done] Función que se llama al finalizar la visualización del diálogo.
     * @return {View} Devuelve la instancia de la vista creada o null si todavía no se ha creado.
     */
    openDialog: function(name, options) {
        var defaults = {
            hide: true,
            style: { display: 'none' }
        };
        options = Object.extend(defaults, options) || defaults;
        if (options.delay) {
            setTimeout(function() {
                delete options.delay;
                uix.openDialog(name, options);
            }, options.delay);
            return;
        }
        // Si no se especifica contendor se añade al cuerpo del documento.
        var container = options.container || document.body;
        // Se comprueba si añadir capa de ocultación.
        if (!options.fullscreen) {
            var overlay = container.querySelector('.uix-overlay');
            // Si no hay capa de ocultación se añade.
            if (!overlay) {
                overlay = uix.create('div', {
                    'class': 'uix-overlay uix-hide --display-none',
                    'data-transition': 'fade'
                });
                container.appendChild(overlay);
            }
        }
        // Si hay algún diálogo abierto en el mismo contenedor se cierra previamente.
        uix.forEach(container.querySelectorAll('.uix-dialog:not(.uix-hide)'), function(el) {
            uix.closeDialog(el);
        });
        // Se crea una capa para envolver y posicionar el diálogo.
        var wrapper = uix.create('div', {
            'class': 'uix-dialog-wrapper uix-hide' + ((options.position === 'bottom') ? ' uix-dialog--bottom' : '')
        });
        container.appendChild(wrapper);
        // Evitamos que los clicks asciendan en el árbol DOM.
        // wrapper.addEventListener('touchend', function(event) {
        //     event.preventDefault();
        // }, false);
        // NOTE: Lo comentamos porque puede provacar que no se produzca ningún click, ni los de dentro del diálogo.
        // Se crea e incluye la vista de diálogo.
        var dialog = View.create(name);
        return dialog.include(wrapper, options, function(err, view) {
            if (err) {
                console.log('Unable to open dialog "' + name + '": ' + err);
                uix.remove(wrapper);
                return;
            }
            // Si se ha incluido el botón de cierre se añade el tratamiento.
            var close = view.root.querySelector('.uix-dialog-close');
            if (close) {
                view.root.querySelector('.uix-dialog-close').addEventListener('tap', function(event) {
                    uix.closeDialog(view);
                });
            }
            // Se visualiza la capa de ocultación.
            if (overlay) {
                uix.toggle(overlay, true);
            }
            // Se visualiza la capa envoltorio.
            uix.toggle(wrapper, true);
            // Se visualiza el diálogo.
            view.toggle(true, options);
            // Si se ha especificado fragmento se añade a la URL actual.
            if (options.fragment) {
                var hash = '#' + options.fragment;
                if (options.history === 'replace') {
                    uix.history.replace(hash);
                } else {
                    uix.history.push(hash);
                }
                // Evento de seguimiento
                uix.track('view_open', view);
            }
            // Se añade el control para cerrar el diálogo cuando la URL cambie.
            uix.history.on('historychange', dialog.onHistoryChange = function() {
                uix.closeDialog(dialog);
            });
        });
    },

    /**
     * Cierra la vista de diálogo especificada.
     * @param {View|Element} dialog Vista de diálogo especificada.
     * @param {function} [callback] Función de retorno.
     */
    closeDialog: function(dialog, callback) {
        if (dialog instanceof Element) {
            dialog = View.find(dialog);
        }
        if (dialog && dialog.isVisible()) {
            var wrapper = dialog.root.parentElement;
                container = wrapper.parentElement,
                overlay = container.querySelector('.uix-overlay');
            dialog.toggle(false, {
                done: function() {
                    dialog.remove();
                    uix.remove(wrapper);
                    if (callback) {
                        callback();
                    }
                }
            });
            if (dialog.onHistoryChange) {
                uix.history.off('historychange', dialog.onHistoryChange);
            }
            if (overlay && uix.isVisible(overlay)) {
                uix.toggle(overlay, false);
            }
        }
    },

    // -----------------------------------------------------------------------------------------------------------------
    /**
     * Muestra un mensaje de error o notificación emergente desde la parte inferior de pantalla, a lo que podemos llamar
     * "tostada".
     * @param {*} message Mensaje a mostrar. Puede ser de cualquier tipo @see uix.create.
     * @param {Object} [options] Opciones adicionales.
     * @param {string} [options.name] Nombre asignado a la tostada, sirve para identificarla y cerrarla posteriormente.
     * @param {boolean} [options.close=true] Indica si mostrar o no el botón de cierre. Por defecto siempre se muestra.
     * @param {number} [options.timeout] Tiempo para el cierre automático (milisegundos).
     * @return {Element} Referencia al elemento creado que nos permite cerrar la tostada
     */
    showToast: function(message, options) {
        var el;
        options = options || {};
        uix.hideToast();
        document.body.appendChild(el = uix.create('div', {
            'class': 'uix-toast uix-hide --display-none',
            'data-transition': 'slide-up'
        }, [
            uix.create('span', {
                'class': 'uix-toast__icon icon icon-warn'
            }),
            uix.create('span', {
                'class': 'uix-toast__text'
            }, message)
        ]));
        if (options.close === undefined || options.close) {
            el.appendChild(uix.create('a', {
                'class': 'uix-toast__close uix-button icon icon-close'
            }, null, {
                'tap': function() {
                    uix.hideToast(el);
                }
            }));
        }
        uix.toggle(el, true);
        if (options.name) {
            el.dataset.name = options.name;
        }
        if (options.timeout) {
            el.dataset.timer = setTimeout(function() {
                uix.hideToast(el);
            }, 10000);
        }
        return el;
    },

    /**
     * Oculta la primera tostada en encontrar enganchada directamente al cuerpo del documento o la especificada por
     * nombre asignado o referencia al elemento raíz de la misma.
     * @param {string|Element} [name] Nombre asignado o referencia al elemento raíz.
     */
    hideToast: function(name) {
        var el = name instanceof Element ? name :
            document.querySelector('body > .uix-toast' + (name ? '[data-name="' + name + '"]' : '') + ':not(.uix-hide)');
        if (el) {
            if (el.dataset.timer) {
                clearTimeout(el.dataset.timer);
            }
            uix.toggle(el, false, {
                remove: true
            });
        }
    },

    // -----------------------------------------------------------------------------------------------------------------
    /**
     * Especificado un elemento con scroll vertical oculta la barra de scroll de sistema y añade una personalizable en
     * apariencia.
     * @param {Element} el Elemento especificado.
     */
    // -----------------------------------------------------------------------------------------------------------------
    // NOTE: Funcionalidad experimental no terminada. El problema aparte de que en Explorer el ajuste de la posición
    // de la barra no es inmediato, es que perdemos la funcionalidad de arrastre con el ratón y eso no nos acaba de
    // gustar.
    // -----------------------------------------------------------------------------------------------------------------
    // customVScroll: function(el) {
    //     // Se construye la barra de scroll
    //     var bar = document.createElement('div');
    //     bar.setAttribute('class', 'uix-vscroll');
    //     var fill = document.createElement('div');
    //     fill.setAttribute('class', 'uix-vscroll-fill');
    //     bar.appendChild(fill);
    //
    //     // Se añade al contenedor
    //     el.appendChild(bar);
    //
    //     // Se ajusta el margen derecho para ocultar la barra de sistema
    //     var margin = (bar.offsetLeft + bar.offsetWidth) - el.offsetWidth;
    //     el.style.marginRight = margin + 'px';
    //
    //     var check = function() {
    //         bar.style.top = el.scrollTop + 'px';
    //         fill.style.height = (100 * el.offsetHeight / el.scrollHeight) + '%';
    //         fill.style.top = (100 * el.scrollTop / el.scrollHeight) + '%';
    //     };
    //
    //     // Se añade el tratamiento de eventos
    //     el.addEventListener('scroll', check);
    // }

};



// =====================================================================================================================
/**
 * Funciones para manejo de formularios.
 * @type {Object}
 */
uix.forms = {

    /**
     * Realiza la inicialización de los componentes del fomulario especificado.
     * @param {Element} form Referencia al formulario o elemento contenedor.
     */
    init: function(form) {
        // Passwords
        var list = form.querySelectorAll('input[type="password"] + .unmask');
        for (var i = 0; i < list.length; i++) {
            list[i].addEventListener('tap', function(event) {
                var el = event.target.previousElementSibling;
                el.type = (el.type === 'password') ? 'text' : 'password';
            });
        }
    },

    /**
     * Añade una nueva regla o función de validación para el campo especificado por medio de un selector y con la
     * posibilidad de especificar opciones adicionales, como la que indica si validar o no los cambios automáticamente.
     * @param {Element} form Referencia al formulario o elemento contenedor.
     * @param {Element|Element[]|NodeList|string} target Referencia a un campo o elemento, array o lista de nodos, o
     * selector para localizarlos dentro del formulario especificado (puede ser múltiple separados por comas).
     * @param {function|Object} [validate] Función de validación u opciones.
     * @param {Object} [options] Opciones adicionales, incluyendo la función de validación si no se especifica como
     * parámetro.
     * @param {function} [options.validate] Función de validación especificada.
     * @param {boolean} [options.changes=true] Indica si validar los campos o elementos frente a cambios añadiendo el
     * tratamiento del evento "change".
     */
    rule: function(form, target, validate, options) {
        // Tratamiento de parámetros
        var defaults = {
            changes: true
        };
        if (typeof validate === 'object' && validate !== null) {
            options = validate;
            validate = null;
        }
        options = options ? Object.extend(defaults, options) : defaults;
        validate = validate || options.validate;

        // Si se ha especificado un selector se evalua
        if (typeof target === 'string') {
            target = form.querySelectorAll(target);
        }

        // Obtención de la lista de reglas añadidas
        var rules = uix.getState(form, 'formRules');
        if (!rules) {
            uix.putState(form, 'formRules', rules = []);
        }

        // Función para añadir una nueva regla
        var add = function(el) {
            rules.push({
                target: el,
                validate: validate
            });
            if (options.changes) {
                el.addEventListener('change', function(event) {
                    uix.forms.validate(form, event.target);
                });
            }
        };
        // Se añaden las reglas
        if (uix.isArrayLike(target)) {
            for (var i = 0; i < target.length; i++) {
                add(target[i]);
            }
        } else {
            add(target);
        }
    },

    /**
     * Valida el formulario especificado al completo, guardando los datos extraídos en el objeto especificado, o si en
     * su lugar se especifica la referencia a un campo, solo se valida el mismo.
     * @param {Element} form Referencia al formulario o elemento contenedor.
     * @param {Object|Element} [data] Objeto donde guardar los datos extraídos durante la validación o referencia al
     * campo concreto a validar.
     * @return {boolean?} Devuelve verdadero si pasa la validación o falso en caso contrario.
     */
    validate: function(form, data) {
        var rules = uix.getState(form, 'formRules');
        if (!rules) {
            console.log('WARNING: Form validation rules not found.');
            return;
        }
        var errors = 0, target;
        if (data instanceof Element) {
            target = data;
            data = null;
        } else {
            uix.forms.clean(form);
        }
        for (var i = 0, el; i < rules.length; i++) {
            el = rules[i].target;
            if (!target || el === target) {
                if (rules[i].validate(el, data) === false) {
                    if (errors++ === 0) {
                        el.focus();
                    }
                }
                if (target) {
                    if (errors === 0) {
                        uix.forms.clean(uix.closest(el, '.uix-line') || el.parentNode);
                    }
                    break;
                }
            }
        }
        return (errors === 0);
    },

    /**
     * Muestra un error general o asociado al campo especificado.
     * @param {Element} target Campo o elemento especificado.
     * @param {string} [message] Texto del mensaje a mostrar.
     * @param {boolean} [focus=false] Indica si mandar el foco al elemento.
     */
    error: function(target, message, focus) {
        if (uix.matches(target, '.uix-form')) {
            if (message) {
                uix.showToast(message);
            } else {
                uix.hideToast();
            }
        } else {
            if (message) {
                var line = uix.closest(target, '.uix-line');
                var msg = (line) ? uix.lastChild(line, '.uix-error-msg') : uix.nextSibling(target, '.uix-error-msg');
                if (msg) {
                    msg.innerHTML = message;
                } else {
                    var code = '<span class="uix-error-msg">' + message + '</span>';
                    if (line) {
                        line.insertAdjacentHTML('beforeend', code);
                    } else {
                        target.insertAdjacentHTML('afterend', code);
                    }
                }
            }
            uix.addClass(target, 'uix-error');
            if (focus) {
                target.focus();
            }
        }
    },

    /**
     * Limpia todos los errores en el formulario o contexto especificado.
     * @param {Element} context Formulario o contexto donde realizar la búsqueda.
     */
    clean: function(context) {
        var errors = context.querySelectorAll('.uix-error');
        for (var i = 0; i < errors.length; i++) {
            uix.removeClass(errors[i], 'uix-error');
        }
        var messages = context.querySelectorAll('.uix-error-msg');
        for (var i = 0; i < messages.length; i++) {
            uix.remove(messages[i]);
        }
    }
};


// =====================================================================================================================
// String Functions
// ---------------------------------------------------------------------------------------------------------------------
/**
 * Capitaliza, pone a mayúsculas, la primera letra de la cadena devolviendo
 * la cadena resultante.
 * @return {string} Cadena resultante.
 */
String.prototype.capFirst = function() {
    return (this.charAt(0).toUpperCase() + this.substr(1));
};

/**
 * Capitaliza la primera letra de todas las palabras de la cadena devolviendo
 * la cadena resultante.
 * @return {string} Cadena resultante.
 */
String.prototype.capWords = function() {
    return (this.replace(/(^|\s)(.)/g , function(m, p1, p2) {
        return (p1 + p2.toUpperCase());
    }));
};


// =====================================================================================================================
// Custom Events
// ---------------------------------------------------------------------------------------------------------------------
// @see {@link https://developer.mozilla.org/en-US/docs/Web/API/CustomEvent/CustomEvent}
(function () {
    if (typeof(window.CustomEvent) === "function") {
        return false;
    }

    function CustomEvent(event, params) {
        params = params || {
            bubbles: false,
            cancelable: false,
            detail: undefined
        };
        var e = document.createEvent('CustomEvent');
        e.initCustomEvent(event, params.bubbles, params.cancelable, params.detail);
        return e;
    }

    CustomEvent.prototype = window.Event.prototype;
    window.CustomEvent = CustomEvent;

})();


// =====================================================================================================================
// Custom Errors
// ---------------------------------------------------------------------------------------------------------------------
function ConnectionError(message) {
    this.name = 'ConnectionError';
    this.message = message || 'No internet connection';
    this.stack = (new Error()).stack;
}
ConnectionError.prototype = Object.create(Error.prototype);
ConnectionError.prototype.constructor = ConnectionError;
/**
 * Funciones para manejo de cookies en cliente.
 * @namespace
 */
var Cookies = {
    /**
     * Crea una nueva cookie, con el nombre, valor y duración en días especificado.
     * @param {string} name Nombre de la cookie.
     * @param {string} value Valor de la cookie.
     * @param {number} days Duración en días.
     * @return {boolean} Devuelve verdadero si se añade la cookie o falso en caso contrario.
     */
    set: function(name, value, days) {
        if (!name || /^(?:expires|max\-age|path|domain|secure)$/i.test(name)) {
            return false;
        }
        document.cookie = encodeURIComponent(name) + '=' + encodeURIComponent(value) +
            '; expires=' + (new Date(Date.now() + (days * 24 * 60 * 60 * 1000))).toUTCString();
        return true;
    },

    /**
     * Devuelve el valor de la cookie con el nombre especificado.
     * @param {string} name Nombre de cookie.
     * @return {?string} Devuelve el valor de la cookie o nulo si no se encuentra.
     */
    get: function(name) {
        if (!name) {
            return null;
        }
        return decodeURIComponent(document.cookie.replace(new RegExp('(?:(?:^|.*;)\\s*' +
                encodeURIComponent(name).replace(/[\-\.\+\*]/g, '\\$&') + '\\s*\\=\\s*([^;]*).*$)|^.*$'), '$1')) || null;
    },

    /**
     * Elimina la cookie con el nombre especificado.
     * @param {string} name Nombre de la cookie a eliminar.
     * @return {boolean} Devuelve verdadero si se elimina la cookie o falso en caso contrario.
     */
    remove: function(name) {
        if (!this.exists(name)) {
            return false;
        }
        document.cookie = encodeURIComponent(name) + '=; expires=Thu, 01 Jan 1970 00:00:00 GMT';
        return true;
    },

    /**
     * Comprueba si la cookie con el nombre especificado existe.
     * @param {string} name Nombre de la cookie.
     * @return {boolean} Devuelve verdadero si existe o falso en caso contrario.
     */
    exists: function(name) {
        if (!name) {
            return false;
        }
        return (new RegExp('(?:^|;\\s*)' + encodeURIComponent(name).replace(/[\-\.\+\*]/g, '\\$&') + '\\s*\\=')).test(document.cookie);
    }
};
/**
 * Importamos la función para convertir la definición de una ruta en la expresión regular equivalente.
 * @see https://github.com/pillarjs/path-to-regexp/blob/master/index.js
 */
var pathToRegexp = (function(module) {

// ---------------------------------------------------------------------------------------------------------------------
// var isarray = require('isarray')
var isarray = Array.isArray || function (arr) {
    return Object.prototype.toString.call(arr) == '[object Array]';
};

// ---------------------------------------------------------------------------------------------------------------------
/**
 * Expose `pathToRegexp`.
 */
module.exports = pathToRegexp
module.exports.parse = parse
module.exports.compile = compile
module.exports.tokensToFunction = tokensToFunction
module.exports.tokensToRegExp = tokensToRegExp

/**
 * The main path matching regexp utility.
 *
 * @type {RegExp}
 */
var PATH_REGEXP = new RegExp([
  // Match escaped characters that would otherwise appear in future matches.
  // This allows the user to escape special characters that won't transform.
  '(\\\\.)',
  // Match Express-style parameters and un-named parameters with a prefix
  // and optional suffixes. Matches appear as:
  //
  // "/:test(\\d+)?" => ["/", "test", "\d+", undefined, "?", undefined]
  // "/route(\\d+)"  => [undefined, undefined, undefined, "\d+", undefined, undefined]
  // "/*"            => ["/", undefined, undefined, undefined, undefined, "*"]
  '([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^()])+)\\))?|\\(((?:\\\\.|[^()])+)\\))([+*?])?|(\\*))'
].join('|'), 'g')

/**
 * Parse a string for the raw tokens.
 *
 * @param  {string} str
 * @return {!Array}
 */
function parse (str) {
  var tokens = []
  var key = 0
  var index = 0
  var path = ''
  var res

  while ((res = PATH_REGEXP.exec(str)) != null) {
    var m = res[0]
    var escaped = res[1]
    var offset = res.index
    path += str.slice(index, offset)
    index = offset + m.length

    // Ignore already escaped sequences.
    if (escaped) {
      path += escaped[1]
      continue
    }

    var next = str[index]
    var prefix = res[2]
    var name = res[3]
    var capture = res[4]
    var group = res[5]
    var modifier = res[6]
    var asterisk = res[7]

    // Only use the prefix when followed by another path segment.
    if (prefix != null && next != null && next !== prefix) {
      path += prefix
      prefix = null
    }

    // Push the current path onto the tokens.
    if (path) {
      tokens.push(path)
      path = ''
    }

    var repeat = modifier === '+' || modifier === '*'
    var optional = modifier === '?' || modifier === '*'
    var delimiter = res[2] || '/'
    var pattern = capture || group || (asterisk ? '.*' : '[^' + delimiter + ']+?')

    tokens.push({
      name: name || key++,
      prefix: prefix || '',
      delimiter: delimiter,
      optional: optional,
      repeat: repeat,
      pattern: escapeGroup(pattern)
    })
  }

  // Match any characters still remaining.
  if (index < str.length) {
    path += str.substr(index)
  }

  // If the path exists, push it onto the end.
  if (path) {
    tokens.push(path)
  }

  return tokens
}

/**
 * Compile a string to a template function for the path.
 *
 * @param  {string}             str
 * @return {!function(Object=)}
 */
function compile (str) {
  return tokensToFunction(parse(str))
}

/**
 * Expose a method for transforming tokens into the path function.
 */
function tokensToFunction (tokens) {
  // Compile all the tokens into regexps.
  var matches = new Array(tokens.length)

  // Compile all the patterns before compilation.
  for (var i = 0; i < tokens.length; i++) {
    if (typeof tokens[i] === 'object') {
      matches[i] = new RegExp('^' + tokens[i].pattern + '$')
    }
  }

  return function (obj) {
    var path = ''
    var data = obj || {}

    for (var i = 0; i < tokens.length; i++) {
      var token = tokens[i]

      if (typeof token === 'string') {
        path += token

        continue
      }

      var value = data[token.name]
      var segment

      if (value == null) {
        if (token.optional) {
          continue
        } else {
          throw new TypeError('Expected "' + token.name + '" to be defined')
        }
      }

      if (isarray(value)) {
        if (!token.repeat) {
          throw new TypeError('Expected "' + token.name + '" to not repeat, but received "' + value + '"')
        }

        if (value.length === 0) {
          if (token.optional) {
            continue
          } else {
            throw new TypeError('Expected "' + token.name + '" to not be empty')
          }
        }

        for (var j = 0; j < value.length; j++) {
          segment = encodeURIComponent(value[j])

          if (!matches[i].test(segment)) {
            throw new TypeError('Expected all "' + token.name + '" to match "' + token.pattern + '", but received "' + segment + '"')
          }

          path += (j === 0 ? token.prefix : token.delimiter) + segment
        }

        continue
      }

      segment = encodeURIComponent(value)

      if (!matches[i].test(segment)) {
        throw new TypeError('Expected "' + token.name + '" to match "' + token.pattern + '", but received "' + segment + '"')
      }

      path += token.prefix + segment
    }

    return path
  }
}

/**
 * Escape a regular expression string.
 *
 * @param  {string} str
 * @return {string}
 */
function escapeString (str) {
  return str.replace(/([.+*?=^!:${}()[\]|\/])/g, '\\$1')
}

/**
 * Escape the capturing group by escaping special characters and meaning.
 *
 * @param  {string} group
 * @return {string}
 */
function escapeGroup (group) {
  return group.replace(/([=!:$\/()])/g, '\\$1')
}

/**
 * Attach the keys as a property of the regexp.
 *
 * @param  {!RegExp} re
 * @param  {Array}   keys
 * @return {!RegExp}
 */
function attachKeys (re, keys) {
  re.keys = keys
  return re
}

/**
 * Get the flags for a regexp from the options.
 *
 * @param  {Object} options
 * @return {string}
 */
function flags (options) {
  return options.sensitive ? '' : 'i'
}

/**
 * Pull out keys from a regexp.
 *
 * @param  {!RegExp} path
 * @param  {!Array}  keys
 * @return {!RegExp}
 */
function regexpToRegexp (path, keys) {
  // Use a negative lookahead to match only capturing groups.
  var groups = path.source.match(/\((?!\?)/g)

  if (groups) {
    for (var i = 0; i < groups.length; i++) {
      keys.push({
        name: i,
        prefix: null,
        delimiter: null,
        optional: false,
        repeat: false,
        pattern: null
      })
    }
  }

  return attachKeys(path, keys)
}

/**
 * Transform an array into a regexp.
 *
 * @param  {!Array}  path
 * @param  {Array}   keys
 * @param  {!Object} options
 * @return {!RegExp}
 */
function arrayToRegexp (path, keys, options) {
  var parts = []

  for (var i = 0; i < path.length; i++) {
    parts.push(pathToRegexp(path[i], keys, options).source)
  }

  var regexp = new RegExp('(?:' + parts.join('|') + ')', flags(options))

  return attachKeys(regexp, keys)
}

/**
 * Create a path regexp from string input.
 *
 * @param  {string}  path
 * @param  {!Array}  keys
 * @param  {!Object} options
 * @return {!RegExp}
 */
function stringToRegexp (path, keys, options) {
  var tokens = parse(path)
  var re = tokensToRegExp(tokens, options)

  // Attach keys back to the regexp.
  for (var i = 0; i < tokens.length; i++) {
    if (typeof tokens[i] !== 'string') {
      keys.push(tokens[i])
    }
  }

  return attachKeys(re, keys)
}

/**
 * Expose a function for taking tokens and returning a RegExp.
 *
 * @param  {!Array}  tokens
 * @param  {Object=} options
 * @return {!RegExp}
 */
function tokensToRegExp (tokens, options) {
  options = options || {}

  var strict = options.strict
  var end = options.end !== false
  var route = ''
  var lastToken = tokens[tokens.length - 1]
  var endsWithSlash = typeof lastToken === 'string' && /\/$/.test(lastToken)

  // Iterate over the tokens and create our regexp string.
  for (var i = 0; i < tokens.length; i++) {
    var token = tokens[i]

    if (typeof token === 'string') {
      route += escapeString(token)
    } else {
      var prefix = escapeString(token.prefix)
      var capture = token.pattern

      if (token.repeat) {
        capture += '(?:' + prefix + capture + ')*'
      }

      if (token.optional) {
        if (prefix) {
          capture = '(?:' + prefix + '(' + capture + '))?'
        } else {
          capture = '(' + capture + ')?'
        }
      } else {
        capture = prefix + '(' + capture + ')'
      }

      route += capture
    }
  }

  // In non-strict mode we allow a slash at the end of match. If the path to
  // match already ends with a slash, we remove it for consistency. The slash
  // is valid at the end of a path match, not in the middle. This is important
  // in non-ending mode, where "/test/" shouldn't match "/test//route".
  if (!strict) {
    route = (endsWithSlash ? route.slice(0, -2) : route) + '(?:\\/(?=$))?'
  }

  if (end) {
    route += '$'
  } else {
    // In non-ending mode, we need the capturing groups to match as much as
    // possible by using a positive lookahead to the end or next path segment.
    route += strict && endsWithSlash ? '' : '(?=\\/|$)'
  }

  return new RegExp('^' + route, flags(options))
}

/**
 * Normalize the given path string, returning a regular expression.
 *
 * An empty array can be passed in for the keys, which will hold the
 * placeholder key descriptions. For example, using `/user/:id`, `keys` will
 * contain `[{ name: 'id', delimiter: '/', optional: false, repeat: false }]`.
 *
 * @param  {(string|RegExp|Array)} path
 * @param  {(Array|Object)=}       keys
 * @param  {Object=}               options
 * @return {!RegExp}
 */
function pathToRegexp (path, keys, options) {
  keys = keys || []

  if (!isarray(keys)) {
    options = /** @type {!Object} */ (keys)
    keys = []
  } else if (!options) {
    options = {}
  }

  if (path instanceof RegExp) {
    return regexpToRegexp(path, /** @type {!Array} */ (keys))
  }

  if (isarray(path)) {
    return arrayToRegexp(/** @type {!Array} */ (path), /** @type {!Array} */ (keys), options)
  }

  return stringToRegexp(/** @type {string} */ (path), /** @type {!Array} */ (keys), options)
}

// ---------------------------------------------------------------------------------------------------------------------
    return module;
})({}).exports;
/**
 * Funciones de utilidad para manejo de URLs.
 * @namespace
 */
var URL = {

    /**
     * Expresión regular para validar y parsear URLs según la norma RFC3986.
     * @see {@link https://tools.ietf.org/html/rfc3986#page-50}
     * @const
     */
    REGEXP: /^(([^:\/?#]+):)?(\/\/([^\/?#]*))?(([^?#]*)(\?([^#]*))?(#(.*))?)/,

    /**
     * Parsea la URL especificada extrayendo cada una de sus partes.
     * @param {string} url URL especificada.
     * @param {boolean} [parseQuery] Indica si parsear los parámetros de consulta formando un objeto.
     * @return {{scheme: string, authority: string, path: string, query: string, fragment: string}} Devuelve un objeto
     * con las partes extraídas.
     * @see {@link https://tools.ietf.org/html/rfc3986}
     */
    parse: function(url, parseQuery) {
        var parts = {}, match;
        if (typeof url === 'string' && (match = url.match(this.REGEXP))) {
            if (match[2] !== undefined) {
                parts.scheme = match[2];
            }
            if (match[4] !== undefined) {
                parts.authority = match[4];
            }
            if (match[6] !== undefined) {
                parts.path = match[6] || '/';
            }
            if (match[8] !== undefined || parseQuery) {
                parts.query = parseQuery ? URL.parseQuery(match[8]) : match[8];
            }
            if (match[10] !== undefined) {
                parts.fragment = match[10];
            }
        }
        return parts;
    },

    /**
     * Analiza la cadena de parámetros de consulta (query) especificada y devuelve un objeto de claves y valores.
     * @param {?string} query Cadena de parámetros especificada.
     * @return {Object} Objeto de claves y valores resultante.
     */
    parseQuery: function(query) {
        var q = {};
        if (query) {
            function decode(str) {
                return decodeURIComponent(str.replace(/\+/g, '%20'));
            }
            if (/^\?/.test(query)) {
                query = query.substr(1);
            }
            for (var i = 0, s = query.split('&'), p, k, v; i < s.length; i++) {
                p = s[i].split('=');
                k = decode(p[0]);
                v = (p.length > 1) ? decode(p[1]) : ''
                if (q[k] === undefined) {
                    q[k] = v;
                } else {
                    if (Array.isArray(q[k])) {
                        q[k].push(v);
                    } else {
                        q[k] = [q[k], v];
                    }
                }
            }
        }
        return q;
    },

    /**
     * Formatea la ruta especificada en partes.
     * @param {Object} parts Partes de la ruta a formatear.
     * @return {string} Cadena formateada.
     */
    format: function(parts) {
        var url = '';
        if (parts.scheme) {
            url += parts.scheme + '://';
        }
        if (parts.authority) {
            url += parts.authority;
        } else if (parts.host) {
            if (parts.userinfo) {
                url += parts.userinfo + '@';
            }
            url += parts.host;
            if (parts.port) {
                url += ':' + parts.port;
            }
        }
        url += parts.path || '/';
        if (parts.query) {
            var qs = (typeof parts.query === 'object' ? URL.formatQuery(parts.query) : parts.query);
            if (qs) {
                url += '?' + qs;
            }
        }
        if (parts.fragment) {
            url += '#' + parts.fragment;
        }
        return url;
    },

    /**
     * Formatea las claves y valores del objeto especificado como una cadena de parámetros de consulta (query).
     * @param {Object} data Objeto de datos especificado.
     * @return {string} Cadena formateada.
     */
    formatQuery: function(data) {
        var params = [];
        for (var name in data) {
            if (data.hasOwnProperty(name) && data[name] != null) {
                params.push(encodeURIComponent(name) + '=' + encodeURIComponent(data[name]));
            }
        }
        return (params.length > 0) ? params.join('&').replace(/%20/g, '+') : '';
    },

    /**
     * Resuelve la ruta especificada con repecto a una ruta base.
     * @param {string} relative Ruta relativa especificada.
     * @param {string} base Ruta base especificada.
     * @return {string} Ruta resultante.
     */
    resolve: function(relative, base) {
        // Absolute
        if (/^[^:/?#]+:\/\//.test(relative)) {
            return relative;
        }
        // Protocol relative
        if (/^\/\//.test(relative)) {
            var match = /^[^:/?#]+:/.exec(base);
            return (match ? match[0] : '') + relative;
        }
        // Relative to the root
        if (/^\//.test(relative)) {
            var match = /^([^:/?#]+:)?\/\/[^/?#]+/.exec(base);
            return (match ? match[0] : '') + relative;
        }
        // Base parts
        // var base = /^([^?#]*)((?:\?[^#]*)?)(#.*)?/.exec(base);

        // Relative to the parent directory
        if (/^\.\.\//.test(relative)) {
            var match = /^[^?#]*/.exec(base);
            return this.resolve(relative.slice(3), match[0].replace(/\/[^/]*$/, ''));
        }
        // Query
        if (/^\?/.test(relative)) {
            var match = /^[^?#]*/.exec(base);
            return match[0] + relative;
        }
        // Fragment
        if (/^#/.test(relative)) {
            var match = /^[^#]*/.exec(base);
            return match[0] + relative;
        }
        // Relative to the current directory
        var match = /^[^?#]*/.exec(base);
        return match[0].replace(/\/[^/]*$/, '') + '/' + relative.replace(/^\.\//, '');
    },

    /**
     * Resuelve la URL especificada con repecto a la localización actual.
     * @param {string} url URL especificada.
     * @return {string} URL resultante.
     */
    qualify: function(url) {
        if (document) {
            var a = document.createElement('a');
            a.href = url;
            url = a.href;
        }
        return url;
    },

    /**
     * Recorta la URL especificada a partir de la ruta, incluyendo parámetros de consulta y fragmento.
     * @param {string} url URL especificada.
     * @return {string} URL resultante.
     */
    trunc: function(url) {
        var match = url.match(this.REGEXP);
        return (match && match[5] !== undefined) ? match[5] : '';
    }
};



// =====================================================================================================================
// CommonJS
// ---------------------------------------------------------------------------------------------------------------------
if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
    module.exports = URL;
}
// =====================================================================================================================
if (!Array.prototype.includes) {
    Array.prototype.includes = function(searchElement/*, fromIndex*/) {
        'use strict';
        var O = Object(this);
        var len = parseInt(O.length) || 0;
        if (len === 0) {
            return false;
        }
        var n = parseInt(arguments[1]) || 0;
        var k;
        if (n >= 0) {
            k = n;
        } else {
            k = len + n;
            if (k < 0) {k = 0;}
        }
        var currentElement;
        while (k < len) {
            currentElement = O[k];
            if (searchElement === currentElement ||
                (searchElement !== searchElement && currentElement !== currentElement)) {
                return true;
            }
            k++;
        }
        return false;
    };
}

/**
 * Compara el array con el array especificado.
 * @param {[]} array Array especificado.
 * @return {boolean} Devuelve true si los arrays son iguales.
 */
Array.prototype.equals = function(arr) {
    if (!Array.isArray(arr)) {
        return false;
    }
    if (this.length != arr.length) {
        return false;
    }
    for (var i = 0; i < this.length; i++) {
        if (typeof this[i] !== typeof obj[i] ||
                typeof this[i] === 'object' && this[i] !== null && !this[i].equals(arr[i]) ||
                this[i] !== arr[i]) {
            return false;
        }
    }
    return true;
}

Object.defineProperty(Array.prototype, 'equals', { enumerable: false });
/**
 * Devuelve un nuevo objeto filtrando las propiedades del objeto especificado, bien mediante una función a la que se le
 * pasa la clave y valor de cada propiedad o bien especificando un array de claves a incluir en el nuevo objeto.
 * @param {Object} obj Objeto especificado.
 * @param {(function|string[])} callback Función para comprobar si incluir cada una de las propiedad o un array con las
 * claves a incluir.
 * @returns {Object|null} El objeto resultante o null si no se especifica correctamente el parámetro callback.
 */
Object.filter = function (obj, callback) {
    if (typeof(callback) === 'object' && Array.isArray(callback)) {
        var keys = callback;
        callback = function(key, value) {
            return (keys.indexOf(key) !== -1);
        };
    } else if (typeof(callback) !== 'function') {
        return null;
    }
    var result = {};
    for (var key in obj) {
        if (obj.hasOwnProperty(key) && callback(key, obj[key])) {
            result[key] = obj[key];
        }
    }
    return result;
};

/**
 * Añade las propiedades de los objetos especificados como argumentos al primero.
 * @param {boolean} [deep] Opcionalmente indica si añadir las propiedades en profundidad cuando las propiedades existan
 * y sean objetos no nulos.
 * @param {Object} obj Objeto destino donde añadir las propiedades.
 * @param {...Object} Objetos especificados cuyas propiedades serán añadidas al primero.
 * @returns {Object} Objeto destino especificado.
 */
Object.extend = function(obj) {
    var deep = false, si = 1;
    if (typeof obj === 'boolean' && arguments.length > 1) {
        deep = obj;
        obj = arguments[1];
        s = 2;
    }
    obj = obj || {};
    for (var i = si; i < arguments.length; i++) {
        if (!arguments[i]) {
            continue;
        }
        for (var key in arguments[i]) {
            if (arguments[i].hasOwnProperty(key)) {
                if (deep && typeof arguments[i][key] === 'object' && typeof obj[key] === 'object' && obj[key] !== null) {
                    Object.extend(obj[key], arguments[i][key]);
                } else {
                    obj[key] = arguments[i][key];
                }
            }
        }
    }
    return obj;
};

/**
 * Determina si el objeto especificado es igual.
 * @param {Object} obj Objeto especificado.
 * @returns {boolean} Devuelve true si los objetos especificados son iguales.
 */
Object.prototype.equals = function(obj) {
    if (typeof obj !== 'object' || obj === null || Array.isArray(obj)) {
        return false;
    }
    var name;
    for (name in this) {
        if (this.hasOwnProperty(name) && (
                !obj.hasOwnProperty(name) ||
                typeof this[name] !== typeof obj[name] ||
                typeof this[name] === 'object' && this[name] !== null && !this[name].equals(obj[name]) ||
                this[name] !== obj[name])) {
            return false;
        }
    }
    for (name in obj) {
        if (obj.hasOwnProperty(name) && !this.hasOwnProperty(name)) {
            return false;
        }
    }
    return true;
};

Object.defineProperty(Object.prototype, 'equals', { enumerable: false });

/**
 * ...
 */
Object.setPrototypeOf = Object.setPrototypeOf || function(obj, proto) {
    obj.__proto__ = proto;
    return obj;
};

if (!String.prototype.startsWith) {
    String.prototype.startsWith = function(stringBuscada, posicion) {
        posicion = posicion || 0;
        return this.indexOf(stringBuscada, posicion) === posicion;
    };
}

if (!String.prototype.endsWith) {
    String.prototype.endsWith = function(searchString, position) {
        var subjectString = this.toString();
        if (typeof position !== 'number' || !isFinite(position) || Math.floor(position) !== position || position > subjectString.length) {
            position = subjectString.length;
        }
        position -= searchString.length;
        var lastIndex = subjectString.indexOf(searchString, position);
        return lastIndex !== -1 && lastIndex === position;
    };
}

if (!String.prototype.format) {
    String.prototype.format = function() {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function(match, index) {
            return (args[index] !== undefined) ? args[index] : match;
        });
    };
}

/*
 * Capa de abstracción sobre el objeto "window.history" que añade el tratamiento adicional del orden de cada entrada
 * añadida lo que nos permite controlar en el tratamiento del evento "popstate" cuando estamos volviendo para atrás o
 * yendo hacía adelante. También añadimos el evento propio "statechange" para notificar cualquier cambio de estado en el
 * histórico, provenga del evento "popstate" o al hacer un "push/replace".
 */
(function() {

    /**
     * Interfaz pública.
     * @namespace
     */
    uix.history = {

        /**
         * Estado actual.
         * @type {Object}
         */
        state: {},

        /**
         * Indica si está activo el formato de URLs "Pretty", codificando las rutas y demás partes en el fragmento de la
         * URL original. Se activa por defecto cuando el protocolo de la localización inicial es "file".
         * @type {boolean}
         */
        pretty: (window.location.protocol === 'file:'),

        /**
         * Número de entradas en el histórico anteriores a la entrada actual.
         * NOTE: A diferencia de la propiedad "window.history.length" no contabiliza las entradas siguientes.
         * @type {number}
         */
        length: 0,

        /**
         * Añade una nueva entrada en el histórico de navegación.
         * @param {string} url Dirección URL.
         * @param {Object} [data] Datos a incluir en el estado.
         * @param {string} [title] Título opcional.
         */
        push: function(url, data, title) {
            if (this.pretty) {
                // TODO: Evaluar si codificar el fragmento con encodeURIComponent()
                url = '#' + URL.resolve(url, (window.location.hash) ? window.location.hash.substring(1) : '/');
            }
            window.history.pushState({
                data: data,
                order: this.length++
            }, title || '', url);
            this.state = window.history.state;
            _fire(new CustomEvent('historychange'));
        },

        /**
         * Reemplaza la entrada actual en el histórico de navegación.
         * @param {string} url Dirección URL.
         * @param {Object} [data] Datos a incluir en el estado.
         * @param {string} [title] Título opcional.
         */
        replace: function(url, data, title) {
            if (this.pretty) {
                // TODO: Evaluar si codificar el fragmento con encodeURIComponent()
                url = '#' + URL.resolve(url, (window.location.hash) ? window.location.hash.substring(1) : '/');
            }
            window.history.replaceState({
                data: data,
                order: (this.length > 0) ? this.length - 1 : this.length++
            }, title || '', url);
            this.state = window.history.state;
            _fire(new CustomEvent('historychange'));
        },

        /**
         * @param {boolean} [parse=false] Indica si parsear la URL extrayendo sus partes.
         * @param {boolean} [parseQuery=false] Indica si parsear los parámetros de consulta.
         * @return {{path: string, query: string, fragment: string}} Devuelve la localización actual.
         * @see URL.parse
         */
        location: function(parse, parseQuery) {
            // TODO: Si codificamos el fragmento hacer la decodificación con decodeURIComponent()
            var url = (this.pretty) ? (window.location.hash) ? window.location.hash.substring(1) : '/'
                : window.location.href;
            return (parse) ? URL.parse(url, parseQuery) : url;
        },

        /**
         * Vuelta atrás en el histórico de navegación.
         */
        back: function() {
            window.history.back();
        }
    };

    // Eventos ---------------------------------------------------------------------------------------------------------
    /**
     * Funciones manejadoras de eventos añadidas por tipo.
     * @type {Object.<string, function(event: Event)[]>}
     * @private
     */
    var _eventListeners = {};

    /**
     * Emite el evento especificado.
     * @param {Event|string} event Evento especificado.
     */
    function _fire(event) {
        if (typeof(event) === 'string') {
            event = new CustomEvent(event);
        }
        var list = _eventListeners[event.type];
        if (list) {
            event.target = this;
            for (var i = 0; i < list.length; i++) {
                list[i].call(this, event);
            }
        }
    };

    /**
     * Añade el manejador de evento al tipo especificado.
     * @param {string} type Tipo de evento.
     * @param {function} handler Función manejadora.
     */
    uix.history.on = function(type, handler) {
        (_eventListeners[type] || (_eventListeners[type] = [])).push(handler);
    };

    /**
     * Elimina el manejador de evento del tipo especificado.
     * @param {string} type Tipo de evento.
     * @param {function} handler Función manejadora.
     */
    uix.history.off = function(type, handler) {
        var list = _eventListeners[type], i;
        if (list && (i = list.indexOf(handler)) !== -1) {
            list.splice(i, 1);
        }
    };

    // -----------------------------------------------------------------------------------------------------------------
    // Tratamiento del evento 'popstate'
    window.addEventListener('popstate', function(event) {
        this.state = event.state;
        var detail = {
            state: event.state
        };
        if (event.state && event.state.order >= 0) {
            detail.back = event.state.order < this.length - 1;
            this.length = event.state.order + 1;
        }
        // NOTE: Aquí existe el inconveniente de que el usuario manipule directamente la URL y modifique el fragmento
        // (hash) generando nuevas entradas en el histórico con estado nulo y no podamos determinar si se trata de una
        // vuelta atrás o el orden que ocupa.
        _fire(new CustomEvent('historypop', {
            detail: detail
        }));
        _fire(new CustomEvent('historychange'));
    }.bind(uix.history));

})();
/*
 * @file share.js
 * @author angel.teran
 */
(function() {

    /**
     * Crea un nuevo objeto para crear y compartir enlaces.
     * @param {Object} properties Propiedades a incluir en el enlace.
     */
    uix.share = function(properties) {
        return new uix.share.ShareObj(properties);
    };

    /**
     * Interfaz de control para crear y compartir enlaces.
     * @param {Object} properties Propiedades del contenido a incluir en la creación del enlace.
     * @class ShareObj
     * @constructor
     */
    uix.share.ShareObj = function(properties) {

        if (typeof Branch !== 'undefined') {
            /**
             * Objeto Universal de Branch (BUO) mediante el cual se generan los enlaces.
             * @see {@link https://blog.branch.io/branch-concepts-the-branch-universal-object/}
             * @see {@link https://blog.branch.io/branch-universal-object-for-deep-linking-and-indexing/}
             * @type {BranchUniversalObject}
             * @private
             */
            this._buo;

            /**
             * Posible error de creación del BUO.
             * @type {*}
             * @private
             */
            this._error;

            /**
             * Funciones en espera de que se complete la creación del BUO.
             * @type {function[]}
             * @private
             */
            this._listeners = [];

            // ---------------------------------------------------------------------------------------------------------
            // Notifica el final de la creación del BUO, con o sin error.
            var notify = function(err) {
                if (this._listeners.length > 0) {
                    for (var i = 0; i < this._listeners.length; i++) {
                        this._listeners[i](err);
                    }
                    this._listeners.length = 0;
                }
            }.bind(this);
            // console.log('[Branch] Creating BUO...');
            Branch.createBranchUniversalObject(properties).then(function(obj) {
                // console.log('[Branch] BUO created: ' + JSON.stringify(obj));
                this._buo = obj;
                notify();
            }.bind(this)).catch(function(err) {
                console.log('[Branch] Error: ' + JSON.stringify(err));
                notify(this._error = err);
            }.bind(this));
        }
    };

    /**
     * Genera un nuevo enlace con las propiedades adicionales especificadas.
     * @param {Object} properties Propiedades adicionales a incluir en la generación del enlace.
     * @param {Object|function} analytics Parámetros adicionales de analítica (canal, campaña, etiquetas, etc.) o
     * función de retorno.
     * @param {function(err: ?Object, url: ?String=)} callback Función de retorno recibe la URL del enlace generado.
     */
    uix.share.ShareObj.prototype.link = function(properties, analytics, callback) {
        if (typeof analytics === 'function') {
            callback = analytics;
            analytics = null;
        }
        analytics = analytics || {};
        if (typeof Branch !== 'undefined') {
            if (this._buo) {
                this._buo.generateShortUrl(analytics, properties).then(function (res) {
                    // console.log('[Branch] Short URL: ' + JSON.stringify(res.url))
                    callback(null, res.url);
                }).catch(function(err) {
                    console.log('[Branch] Error: ' + JSON.stringify(err));
                    callback(err);
                });
            } else if (this._error) {
                callback(this._error);
            } else {
                this._listeners.push(function (err) {
                    if (err) {
                        callback(err);
                    } else {
                        this.link(properties, callback);
                    }
                }.bind(this));
            }
        } else {
            // TODO: Integrar e implementar Branch para web.
            callback(null, uix.history.location());
        }
    };

})();
/**
 * taps.js
 */
(function() {

    // Settings --------------------------------------------------------------------------------------------------------
    /**
     * Mínima longitud de desplazamiento en los ejes (pixels).
     * @type {number}
     */
    var motionThreshold = 12;

    /**
     * Tiempo máximo en milisegundos para lanzar el evento de deslizamiento rápido (swipe).
     * @type {number}
     */
    var swipeTime = 500;

    /**
     * Tiempo en milisegundos para la lanzar el evento de pulsación larga (press).
     * @type {number}
     */
    var pressTime = 300;

    /**
     * Tiempo máximo en milisegundos para lanzar el evento de pulsación doble (doubletap).
     * @type {number}
     */
    var doubleTapTime = 300;

    /**
     * Margen de tiempo en milisegundos desde el último evento táctil en el que ignorar eventos de ratón posteriores.
     * @type {number}
     */
    var touchGap = 1000; // TODO: ¿No es muy alto?, ¿no estaría mejor dejarlo en 500 ms?...

    /**
     * Opciones de captura de eventos.
     * @type {{capture: boolean, passive: boolean}}
     */
    var captureOptions = { capture: true, passive: true };


    // Variables -------------------------------------------------------------------------------------------------------
    /**
     * Representa una entrada en el mapa de seguimiento de eventos de interacción táctil o de ratón.
     * @typedef {Object} TrackEntry
     * @property {EventTarget|Element} target Referencia al elemento donde se origina el evento.
     * @property {number} startTime Tiempo de inicio de la secuencia de eventos.
     * @property {number} endTime Tiempo de finalización de la secuencia de eventos.
     * @property {number} dt Tiempo transcurrido entre el inicio y el final de la secuencia.
     * @property {number} x0 Coordenada X inicial.
     * @property {number} y0 Coordenada Y inicial.
     * @property {number} x Coordenada X actual.
     * @property {number} y Coordenada Y actual.
     * @property {number} dx Desplazamiento de la coordenada X.
     * @property {number} dy Desplazamiento de la coordenada Y.
     * @property {?('horizontal'|'vertical')} orientation Orientación del desplazamiento.
     * @property {?('up'|'right'|'down'|'left')} direction Dirección del desplazamiento.
     * @property {boolean} [swiping] Indica si al finalizar el gesto de arrastre (dragend) se considera un deslizamiento
     * rápido (swipe).
     */

    /**
     * Referencia al elemento raíz del documento donde añadir el manejo de eventos.
     */
    var root = document.documentElement;

    /**
     * Mapa de seguimiento de eventos de interacción táctil o de ratón.
     * El identificador de la entrada se forma añadiendo al método de interacción táctil (touch) o de ratón (mouse)
     * el identificador del punto de contacto en eventos táctiles (touch:0, touch:1...).
     * @see https://developer.mozilla.org/en-US/docs/Web/API/Touch/identifier
     * @type {Object.<string, TrackEntry>}
     */
    var track = {};

    /**
     * Indica el número de puntos de contacto activos en cada instante.
     * @type {number}
     */
    var touching = 0;

    /**
     * Indica el tiempo de finalización del último evento táctil (ms).
     * @type {number}
     */
    var touchEndTime = 0;

    /**
     * Indica el tiempo de finalización del último evento táctil (ms).
     * @type {number}
     */
    var touchEndTime = 0;

    // Functions -------------------------------------------------------------------------------------------------------
    /**
     * Crea la entrada para seguimiento de una nueva interacción táctil o de ratón.
     * @param {string} id Identificador de entrada.
     * @param {EventTarget|Element} target Elemento implicado en la interacción.
     * @param {number} x Coordenada X.
     * @param {number} y Coordenada Y.
     */
    function trackStart(id, target, x, y) {
        // console.log('trackStart: ' + id);
        // Se crea la nueva entrada
        var entry = track[id] = {
            target: target,
            startTime: performance.now(),
            endTime: 0,
            dt: 0,
            x0: x,
            y0: y,
            x: x,
            y: y,
            dx: 0,
            dy: 0,
            orientation: null,
            direction: null
        };

        // Se crea el temporizador para lanzar el evento de pulsación larga transcurrido el tiempo establecido
        target.setAttribute('data-press-timer', setTimeout(function() {
            fire(entry, 'press');
        }, pressTime));

        // Evento de inicio de interacción
        fire(entry, 'tapstart');
    }

    /**
     * Tratamiento de los eventos de desplazamiento.
     * @param {string} id Identificador de la entrada.
     * @param {number} x Coordenada X.
     * @param {number} y Coordenada Y.
     */
    function trackMove(id, x, y) {
        // console.log('trackMove: ' + id);
        var entry = track[id];
        entry.x = x;
        entry.y = y;
        entry.dx = entry.x - entry.x0;
        entry.dy = entry.y - entry.y0;

        // Se comprueba si ya se ha iniciado el movimiento
        if (entry.orientation) {
            fire(entry, 'drag');
        } else {
            // Se comprueba que haya un desplazamiento mínimo en los ejes
            var adx = Math.abs(entry.dx);
            var ady = Math.abs(entry.dy);
            if (adx > motionThreshold || ady > motionThreshold) {
                // Se calcula la orientación y dirección del movimiento
                if (adx > ady) {
                    entry.orientation = 'horizontal';
                    entry.direction = (entry.dx > 0) ? 'right' : 'left';
                }
                else {
                    entry.orientation = 'vertical';
                    entry.direction = (entry.dy > 0) ? 'down' : 'up';
                }
                fire(entry, 'dragstart');
                fire(entry, 'drag');

                // Se cancela el evento de pulsación larga (press)
                var pressTimer = entry.target.getAttribute('data-press-timer');
                if (pressTimer) {
                    clearTimeout(pressTimer);
                    entry.target.removeAttribute('data-press-timer');
                }
            }
        } // if (entry.orientation) else
    }

    /**
     * Tratamiento del final de una interacción.
     * @param {string} id Identificador de la entrada.
     * @param {boolean} [cancel] Indica si cancelar la interacción.
     */
    function trackEnd(id, cancel) {
        // console.log('trackEnd: ' + id);
        var entry = track[id];

        // Se cancela el evento de pulsación larga (press)
        var pressTimer = entry.target.getAttribute('data-press-timer');
        if (pressTimer) {
            clearTimeout(pressTimer);
            entry.target.removeAttribute('data-press-timer');
        }

        if (!cancel) {
            // Se actualiza el tiempo de finalización y se calcula el tiempo transcurrido
            entry.endTime = performance.now();
            entry.dt = entry.endTime - entry.startTime;

            // Se lanza el evento o eventos correspondientes
            if (entry.orientation) {
                entry.swiping = entry.dt < swipeTime;
                if (entry.swiping) {
                    fire(entry, 'swipe');
                }
                fire(entry, 'dragend');

            } else {
                var doubleTapTimer = entry.target.getAttribute('data-doubletap-timer');
                if (doubleTapTimer) {
                    fire(entry, 'doubletap');
                    clearTimeout(doubleTapTimer);
                    entry.target.removeAttribute('data-doubletap-timer');
                } else {
                    fire(entry, 'tap');
                    var target = entry.target;
                    entry.target.setAttribute('data-doubletap-timer', setTimeout(function() {
                        target.removeAttribute('data-doubletap-timer');
                    }, doubleTapTime));
                }
            }
        }

        // Evento de final de interacción
        fire(entry, 'tapend');

        // Se elimina la entrada de seguimiento
        delete track[id];
    }

    // Touch events ----------------------------------------------------------------------------------------------------
    /**
     * Tratamiento del inicio de un evento táctil.
     * @param {TouchEvent} event Evento táctil recibido.
     */
    function touchStart(event) {
        if (!event.changedTouches) {
            return;
        }
        // Se evalua todos los puntos de contacto
        for (var i = 0; i < event.changedTouches.length; i++) {
            // Se crea la nueva entrada para seguimiento de la interacción
            trackStart('touch:' + event.changedTouches[i].identifier, event.target,
                event.changedTouches[i].pageX, event.changedTouches[i].pageY);
            // Si es el primero punto de contacto, se añade el tratamiento de los eventos posteriores
            if (touching === 0) {
                on('touchmove', touchMove, captureOptions);
                on(['touchend', 'touchcancel'], touchEnd, captureOptions);
            }
            // Se incrementa el contador de puntos de contacto activos
            touching++;
            // Se añade la clase de estilo "touch" a la raíz del documento para indicar la interacción táctil.
            if (touching === 1 && !root.classList.contains('touch')) {
                root.classList.add('touch');
                on('mousemove', touchCheck, captureOptions);
            }
        }
    }

    /**
     * Tratamiento del evento de desplazamiento táctil.
     * @param {TouchEvent} event Evento táctil recibido.
     */
    function touchMove(event) {
        // Se evalua todos los puntos de contacto
        for (var i = 0; i < event.changedTouches.length; i++) {
            // Se realiza el tratamiento del desplazamiento para cada punto de contacto
            trackMove('touch:' + event.changedTouches[i].identifier,
                event.changedTouches[i].pageX, event.changedTouches[i].pageY);
        }
    }

    /**
     * Tratamiento del final de un evento táctil.
     * @param {TouchEvent} event Evento táctil recibido.
     */
    function touchEnd(event) {
        // Se evalua todos los puntos de contacto
        for (var i = 0, e; i < event.changedTouches.length; i++) {
            trackEnd('touch:' + event.changedTouches[i].identifier, event.type !== 'touchend');
            // Se decrementa el número de puntos de contacto activos y se guarda el tiempo final
            touching--;
            touchEndTime = performance.now();
        }
        // Se elimina el tratamiento de eventos añadidos
        if (touching === 0) {
            off('touchmove', touchMove, captureOptions);
            off(['touchend', 'touchcancel'], touchEnd, captureOptions);
        }
    }

    /**
     * Comprueba si hay una interacción táctil activa o si el tiempo desde la última es menor que el margen establecido
     * (touchGap).
     * @return {boolean} Devuelve true si la interacción es táctil.
     */
    function touchCheck() {
        if (touching > 0 || touchEndTime > 0 && touchGap > (performance.now() - touchEndTime)) {
            return true;
        }
        // Si no hay interacción táctil se comprueba si eliminar la clase de estilo "touch" de la raíz del documento así
        // como el tratamiento del evento 'mousemove' para realizar esta comprobación.
        if (root.classList.contains('touch')) {
            root.classList.remove('touch');
            off('mousemove', touchCheck, captureOptions);
        }
    }


    // Mouse Events ----------------------------------------------------------------------------------------------------
    /**
     * Tratamiento del inicio de un evento de ratón.
     * @param {Event} event Evento recibido.
     */
    function mouseStart(event) {
        // Se comprueba si hay una interacción táctil activa o si el tiempo desde la última es menor que el margen
        // establecido, descartando todos los eventos de ratón simulados que lleguen en estos casos.
        if (touchCheck()) {
            return;
        }
        // Se crea la nueva entrada para seguimiento de la interacción
        trackStart('mouse', event.target, event.pageX, event.pageY);
        // Se añade el tratamiento de los eventos posteriores
        on('mousemove', mouseMove, captureOptions);
        on('mouseup', mouseEnd, captureOptions);
    }

    /**
     * Tratamiento del evento de desplazamiento con el ratón.
     * @param {Event} event Evento recibido.
     */
    function mouseMove(event) {
        trackMove('mouse', event.pageX, event.pageY);
    }

    /**
     * Tratamiento del final de un evento de ratón.
     */
    function mouseEnd() {
        trackEnd('mouse');
        // Se elimina el tratamiento de eventos añadidos
        off('mousemove', mouseMove, captureOptions);
        off('mouseup', mouseEnd, captureOptions);
    }

    // Utility functions -----------------------------------------------------------------------------------------------
    /**
     * Añade el tratamiento del evento o eventos especificados.
     * @param {string|string[]} type Tipo o tipos de evento especificados.
     * @param {function} handler Función para tratamiento del evento.
     * @param {boolean} capture Indica si añadir el tratamiento en la fase de captura del evento.
     */
    function on(type, handler, capture) {
        if (Array.isArray(type)) {
            for (var i = 0; i < type.length; i++) {
                root.addEventListener(type[i], handler, capture);
            }
        } else {
            root.addEventListener(type, handler, capture);
        }
    }

    /**
     * Elimina el tratamiento del evento o eventos especificados.
     * @param {string|string[]} type Tipo o tipos de evento especificados.
     * @param {function} handler Función para tratamiento del evento añadida anteriormente.
     * @param {boolean} capture Indica si el tratamiento a eliminar fue añadido para la fase de captura o no.
     */
    function off(type, handler, capture) {
        if (Array.isArray(type)) {
            for (var i = 0; i < type.length; i++) {
                root.removeEventListener(type[i], handler, capture);
            }
        } else {
            root.removeEventListener(type, handler, capture);
        }
    }

    /**
     * Lanza el tipo de evento especificado.
     * @param {TrackEntry} entry Información de seguimiento de la interacción.
     * @param {string} type Tipo de evento especificado.
     */
    function fire(entry, type) {
        var event = new CustomEvent(type, {
            detail: entry,
            bubbles: true
        });
        entry.target.dispatchEvent(event);
        /* TODO: Posibilitar el preventDefault() !!!
        if (event.defaultPrevented) {
            entry.defaultPrevented = true;
        } */
    }


    // Initialization --------------------------------------------------------------------------------------------------
    on('touchstart', touchStart, captureOptions);
    on('mousedown', mouseStart, captureOptions);
})();
/*
 * Almacenamiento persistente de información simple de tipo clave/valor como preferencias, ajustes de configuración,
 * datos de sesión, etc. No emplear para almacenar información más compleja ni cachear datos cargados.
 * Se usa en primera instancia el plugin de Cordova NativeStorage:
 * @see {https://github.com/TheCocoaProject/cordova-plugin-nativestorage}.
 * Si no se encuentra dicho plugin se usa el API Web estándar para almacenamiento local de datos:
 * @see {https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API}
 * @file store.js
 * @author angel.teran
 */
(function() {

    // Private ---------------------------------------------------------------------------------------------------------
    /**
     * Crea una función de retorno intermedia personalizando el mensaje en caso de error.
     * @param {string} msg Mensaje de error especificado.
     * @param {Function} [callback] Función de retorno especificada.
     * @return {Function} Función de retorno intermedia creada.
     * @private
     */
    function _callback(msg, callback) {
        return function (err, value) {
            if (err) {
                _log(msg + ': ' + JSON.stringify(err));
            }
            if (callback) {
                callback(err, value);
            }
        };
    }

    /**
     * Escribe un mensaje por consola.
     * @param {string} msg Mensaje a escribir.
     * @private
     */
    function _log(msg) {
        console.log('[uix.store] ' + msg);
    }

    // Interface -------------------------------------------------------------------------------------------------------
    /**
     * Interfaz pública.
     * @namespace
     */
    uix.store = {

        /**
         * Devuelve el valor almacenado para la clave especificada.
         * @param {string} key Clave especificada.
         * @param {function(err: ?Error, value: ?*=)} callback Función de retorno.
         */
        get: function(key, callback) {
            var cb = _callback('Unable to recover the key "' + key + '"', callback);
            if (window.NativeStorage) {
                window.NativeStorage.getItem(key, function(value) {
                    cb(null, value);
                }, function(err) {
                    cb((err.code === 2) ? null : err, null);
                });
            } else {
                try {
                    cb(null, window.localStorage.getItem(key));
                } catch (err) {
                    cb(err);
                }
            }
        },

        /**
         * Guarda un nuevo valor asociado a la clave especificada.
         * @param {string} key Clave especificada.
         * @param {*} value Valor especificado.
         * @param {function(err: ?Error)} [callback] Función de retorno.
         */
        put: function(key, value, callback) {
            var cb = _callback('Unable to store the key "' + key + '"', callback);
            if (window.NativeStorage) {
                window.NativeStorage.setItem(key, value, function() {
                    cb(null);
                }, function(err) {
                    cb(err, null);
                });
            } else {
                try {
                    window.localStorage.setItem(key, value);
                    cb(null);
                } catch (err) {
                    cb(err);
                }
            }
        },

        /**
         * Elimina el valor asociado a la clave especificada.
         * @param {string} key Clave especificada.
         * @param {function(err: ?Error)} [callback] Función de retorno.
         */
        remove: function(key, callback) {
            var cb = _callback('Unable to remove the key "' + key + '"', callback);
            if (window.NativeStorage) {
                window.NativeStorage.remove(key, function() {
                    cb(null);
                }, function(err) {
                    cb(err);
                });
            } else {
                try {
                    window.localStorage.removeItem(key);
                    cb(null);
                } catch (err) {
                    cb(err);
                }
            }
        },

        /**
         * Vacía el almacenamiento al completo.
         * @param {function(err: ?Error)} [callback] Función de retorno.
         */
        clear: function(callback) {
            var cb = _callback('Unable to clear the storage', callback);
            if (window.NativeStorage) {
                window.NativeStorage.clear(function() {
                    cb(null);
                }, function(err) {
                    cb(err);
                });
            } else {
                try {
                    window.localStorage.clear();
                    cb(null);
                } catch (err) {
                    cb(err);
                }
            }
        }
    };
})();
/**
 * Objeto base para manejadores de vistas.
 * @param {Object} [settings] Ajustes iniciales de creación de la vista.
 * @class
 */
function View(settings) {

    // Ajustes por defecto
    settings = settings || {};

    /**
     * Identificador único de la vista.
     * @type {string}
     * @private
     */
    this.uid = View.cache.put(this);

    /**
     * Referencia al elemento raíz de la vista.
     * @type {HTMLElement}
     * @private
     */
    this.root = null;

    /**
     * Nombre de la plantilla asociada.
     * @type {string}
     * @private
     */
    this.template = settings.template || null;

    /**
     * Referencia a la vista padre, ascendiente o contenedora.
     * @type {View}
     * @private
     */
    this.parentView = settings.parentView || null;

    /**
     * URL de datos.
     * @type {string}
     * @private
     */
    this.dataURL = settings.dataURL || null;

    /**
     * Posición de scroll asociada a la vista.
     * @type {{top: number, left: number}}
     * @protected
     */
    this.scroll = null;

    /**
     * Funciones manejadoras de eventos añadidas por tipo.
     * @type {Object.<string, function(event: Event)[]>}
     * @private
     */
    this.eventListeners = {};

    /**
     * Ruta o nombre enclave a emplear para el registro de eventos de seguimiento cuando se visualiza la vista en algún
     * contenedor a través del objeto Viewport o como diálogo (uix.openDialog).
     * - Puede ser de tipo string o una función que se llamará cada vez que se vaya a emitir un evento.
     * - Si no se define ningún valor se usará la URL o localización actual.
     * - Para evitar que se emitan eventos de seguimiento automáticamente asignar un valor nulo.
     * @name trackPath
     * @type {string|function|null>}
     * @protected
     */
    // this.trackPath = undefined;

    // Creación e inicialización
    // -----------------------------------------------------------------------------------------------------------------
    this.create(settings);
};

// ---------------------------------------------------------------------------------------------------------------------
/**
 * Índice de manejadores de vista por nombre.
 * @type {Object.<string, function>}
 */
View.handlers = {};

/**
 * Índice de plantillas de vista por nombre.
 * @type {Object.<string, function>}
 */
View.templates = {};

// ---------------------------------------------------------------------------------------------------------------------
/**
 * Define un nuevo tipo de vista.
 * @param {string} name Nombre de la nueva vista.
 * @param {string|Object} [base] Nombre de la vista base de la cual extender el prototipo de la nueva vista.
 * @param {Object} proto Prototipo de la nueva vista.
 * @returns {function(new:View, Object=)} Devuelve la función constructora del nuevo tipo de vista creado.
 */
View.define = function(name, base, proto) {
    if (typeof(base) === 'object') {
        proto = base;
        base = null;
    }
    var B = (base) ? View.handlers[base] : View;
    var T = function(settings) {
        B.call(this, settings);
    };
    T.prototype = Object.extend(Object.create(B.prototype), proto);
    T.prototype.constructor = T;
    /** @memberof View */
    T.prototype.__view_name = name;
    return View.handlers[name] = T;
};

/**
 * Comprueba si existe una vista o plantilla con el nombre especificado.
 * @param {string} name Nombre especificado.
 * @return {boolean} Devuelve verdadero si la vista existe y falso en caso contrario.
 */
View.exists = function(name) {
    return !!(View.handlers[name] || View.templates[name]);
};

/**
 * Crea una nueva instancia del tipo de vista especificado. También se pueden crear vistas sin tipo definido a partir de
 * una plantilla.
 * @param {string} name Nombre del tipo de vista o plantilla.
 * @param {Object} [settings] Ajustes iniciales de creación de la vista.
 * @return {View} Devuelve la nueva instancia de la vista creada.
 */
View.create = function(name, settings) {
    var view;
    if (View.handlers[name]) {
        view = new View.handlers[name](settings);
    } else if (View.templates[name]) {
        view = new View(Object.extend(settings, {
            template: name
        }));
    } else {
        throw new Error('View \'' + name + '\' not found.');
    }
    return view;
};

/**
 * Renderiza la plantilla especificada en el contexto de generación de una vista de manera asíncrona, pasando el
 * elemento raíz de la estructura HTML generada (root) a la función de retorno una vez completada la inclusión y
 * generación de todas las subvistas incluidas.
 * @param {View|string} [view] Instancia de la vista sobre la que llamar al renderizado de la plantilla a la que le
 * llegará como referencia 'this'.
 * @param {string} template Nombre de la plantilla.
 * @param {Object|function} [options] Opciones adicionales de inclusión de la vista o función de retorno.
 * @param {function(err: ?Object, root: ?HTMLElement=)} [complete] Función de retorno donde se incluye la raíz de la vista
 * generada.
 */
View.render = function(view, template, options, complete) {
    if (typeof(view) === 'string') {
        complete = options;
        options = template;
        template = view;
        view = null;
    }
    if (typeof(options) === 'function') {
        complete = options;
        options = {};
    }

    // Se comprueba si existe la plantilla
    if (!View.templates[template]) {
        return complete(new Error('Template \'' + template + '\' not found.'));
    }

    // Contexto (elemento) donde renderizar la plantilla
    var context = document.createElement('div'),
        includeQueue = [];

    /**
     * Función para incluir sub-vistas o plantillas.
     * @param {string} name Nombre de vista o plantilla.
     * @param {Object|function} [settings] Ajustes iniciales de creación de la vista.
     * @param {View} [settings.parentView] Referencia a la vista padre contenedora.
     * @param {Object|function} [options] Opciones adicionales de inclusión de la vista.
     * @param {string} [options.member] Nombre de la variable a asignar en la instancia de la vista padre.
     * @param {function(err: ?Object, root: ?HTMLElement=)} complete Función de retorno.
     * @return {string} Código HTML para anclar la vista que luego se sustuirá por cada vista.
     */
    var includeView = function(name, settings, options, complete) {
        if (typeof settings === 'function') {
            complete = settings;
            settings = options = null;
        } else if (typeof options === 'function') {
            complete = options;
            options = null;
        }
        settings = settings || {};
        options = options || settings;
        if (view && !settings.parentView) {
            settings.parentView = view;
        }
        var v = View.create(name, settings);
        if (view && typeof options.member === 'string') {
            view[options.member] = v;
        }
        var id = 'include-view-' + v.uid;
        includeQueue.push({
            id: id,
            name: name,
            view: v,
            options: options,
            complete: complete
        });
        return '<div id="' + id + '"></div>';
    };
    try {
        context.innerHTML = View.templates[template].call(view, options, null, includeView);
    } catch (err) {
        complete(err);
        return;
    }

    // Se obtiene el elemento raíz de la vista
    var // frag = document.createDocumentFragment(),
        root = context.firstElementChild;
    // frag.appendChild(root);

    // Si hay inclusiones se resuelven
    if (includeQueue.length > 0) {
        var errors = [];
        for (var i = 0, c = includeQueue.length, include, anchor; i < includeQueue.length; i++) {
            include = includeQueue[i];
            anchor = root.querySelector('#' + include.id);
            include.view.include(anchor, Object.extend(include.options, {
                replace: true
            }), function(err, view) {
                if (err) {
                    errors.push(err = new ViewError('Unable to include \'' + include.name + '\': ' + err.toString(), err));
                    console.log(err);
                }
                if (include.complete) {
                    include.complete(err, view);
                }
                if (--c === 0) {
                    if (errors.length > 1) {
                        var msg = 'Unable to complete render of \'' + template + '\':\n';
                        for (var i = 0; i < errors.length; i++) {
                            msg += '\t- ' + errors[i].toString() + '\n';
                        }
                        err = new ViewError(msg, errors);
                    }
                    complete(err, root);
                }
            });
        }
    } else {
        complete(null, root);
    }
};

// ---------------------------------------------------------------------------------------------------------------------
/**
 * Cache de instancias de vistas por identificador único.
 */
View.cache = {

    /**
     * Mapa de instancias por identificador único.
     * @type {Object.<number, View>}
     */
    map: {},

    /**
     * Último identificador único asignado.
     * @type {number}
     */
    uid: 0,

    /**
     * Añade una nueva vista a la cache.
     * @param {View} view Vista especificada.
     * @return {string} Devuelve el identificador único asignado a la vista.
     */
    put: function(view) {
        this.map[++this.uid] = view;
        return this.uid.toString();
    },

    /**
     * Devuelve la instancia asignada al identificador único especificado.
     * @param {string} id Identificador único de la vista.
     * @return {View} Instancia de la vista o null si no existe ninguna vista con ese identificador.
     */
    get: function(id) {
        return (id && id in this.map) ? this.map[id] : null;
    },

    /**
     * Elimina de la cache la vista asociada al identificador especificado.
     * @param {string} id Identificador único de la vista.
     */
    remove: function(id) {
        delete this.map[id];
    }
};

/**
 * Busca la vista asociada al elemento especificado o si se especifica un selector al primer elemento contenido que
 * coincida con el mismo.
 * @param {HTMLElement|string} el Elemento especificado o selector.
 * @param {string} [selector] Selector especificado.
 * @return {View} Vista obtenida o null si no se encuentra ninguna vista.
 */
View.find = function(el, selector) {
    if (typeof el === 'string') {
        el = document.querySelector(el);
    } else if (selector) {
        el = el.querySelector(selector);
    }
    return (el && el.dataset.viewId) ? View.cache.get(el.dataset.viewId) : null;
};



// ---------------------------------------------------------------------------------------------------------------------
/**
 * Añade una nueva plantilla con el nombre especificado.
 * @param {string} name Nombre de la plantilla.
 * @param {function} template Función que genera el código de la plantilla.
 */
View.putTemplate = function(name, template) {
    var defaultIndex = '/layout',
        i = name.length - defaultIndex.length;
    if (i > 0 && name.indexOf(defaultIndex, i) === i) {
        name = name.substr(0, i);
    }
    View.templates[name] = template;
};

/**
 * Escapa el código de marcado especificado convirtiendo los cararácteres especiales a las entidades correspondientes.
 * @param {string} code Código especificado.
 * @returns {string} Código resultante.
 */
View.escape = function(code) {
    return (code === undefined) ? '' : String(code).replace(/[&<>'"]/g, function(c) {
        return View.escape.CHARS[c] || c;
    });
};

/**
 * Caracteres especiales de marcado y entidades correspondientes.
 * @type {Object.<string, string>}
 */
View.escape.CHARS = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&#34;',
    "'": '&#39;'
};

// ---------------------------------------------------------------------------------------------------------------------
/**
 * Función de creación e inicialización de la vista.
 * @param {Object} [settings] Ajustes u opciones iniciales.
 * @constructs
 */
View.prototype.create = function(settings) {
    // NOTE: Implementar por objetos derivados...
};

/**
 * Incluye la vista en el elemento destino especificado.
 * @param {HTMLElement} target Elemento destino especificado.
 * @param {Object|function} [options] Opciones adicionales de inclusión de la vista o función de retorno.
 * @param {Object} [options.replace] Indica si reemplazar el elemento destino especificado en lugar de añadir la vista
 * al final del mismo
 * @param {Object} [options.hide] Indica si ocultar el elemento en la inclusión.
 * @param {Object} [options.style] Estilos adicionales a añadir en la inclusión.
 * @param {function(err: ?Error=, view: View=)} [complete] Función de retorno.
 * @return {View} Devuelve la instancia de la vista.
 */
View.prototype.include = function(target, options, complete) {
    var self = this,
        defaults = {};
    if (typeof(options) === 'function') {
        complete = options;
        options = defaults;
    } else {
        options = options || defaults;
    }
    var attach = function(load) {
        if (options.replace) {
            target.parentNode.replaceChild(self.root, target);
        } else {
            target.appendChild(self.root);
        }
        self.root.offsetWidth + self.root.offsetHeight; // -> REFLOW
        // TODO: Evalur si llamar al ready dentro de un requestAnimationFrame()
        if (load) {
            self.ready(self.root, options);
            self.fire('vready');
        } else {
            self.restoreScroll();
        }
        if (complete) {
            complete(null, self);
        }
    };
    if (this.root) {
        attach();
    } else {
        this.load(options, function (err, data) {
            if (err) {
                return (complete && complete(err));
            }
            if (data) {
                options.data = data;
            }
            self.render(options, function (err, root) {
                if (err) {
                    return (complete && complete(err));
                }
                self.root = root;
                root.dataset.viewId = self.uid;
                if (options.hide) {
                    uix.addClass(root, 'uix-hide');
                }
                if (options.style) {
                    Object.extend(root.style, options.style);
                }
                attach(true);
            });
        });
    }
    return this;
};

/**
 * Genera la representación gráfica de la vista. Por defecto, si no se sobrescribe la función, se emplea el nombre de
 * plantilla especificado en la propiedad 'template'. Si este no se define se busca una plantilla con el mismo nombre
 * que la vista, dado al registrar el manejador. Los objetos derivados pueden variar este comportamiento, haciendo uso
 * de una o más plantillas, sin que sea necesario que el nombre de la plantilla y el manejador de la vista coincidan.
 * @param {?Object} [options] Opciones adicionales de inclusión de la vista.
 * @param {function(err: ?Object, root: ?HTMLElement=)} complete Función de retorno donde se incluye la raíz de la vista
 * generada si no hay errores.
 * @access protected
 */
View.prototype.render = function(options, complete) {
    // NOTE: Implementar por objetos derivados que requieran una implementación más específica del renderizado de la vista.
    View.render(this, this.template || this.__view_name, options, complete);
};

/**
 * Carga de datos. Por defecto, si no se sobrescribe la función, se intentará cargar la URL indicada en la propiedad
 * 'dataURL' si está definida.
 * @param {?Object} options Opciones adicionales de carga.
 * @param {function(err: ?Object, data: Object=)} complete Función de retorno.
 * @access protected
 */
View.prototype.load = function(options, complete) {
    // NOTE: Implementar por objetos derivados que requieran una implementación específica de la carga de datos adicionales.
    var dataURL = this.dataURL || options.dataURL;
    if (dataURL) {
        uix.load(dataURL, complete);
    } else {
        complete(null, null);
    }
};

/**
 * Recarga la vista cuando sea necesario según el criterio implementado en cada caso, o siempre que se fuerce por medio
 * del parámetro 'force'.
 * @param {?Object|function} [options] Opciones adicionales de recarga de la vista o función de retorno siguiente.
 * @param {function(err: ?Object=)} [complete] Función de retorno.
 * @access protected
 */
View.prototype.reload = function(options, complete) {
    // NOTE: Implementar por objetos derivados para una implementación específica de la recarga de la vista.
    // En la implementación por defecto se recarga y renderiza la vista al completo, reemplazando el elemento raíz si
    // está enganchado a un documento o bajo la estructura de otra vista.
    if (!this.root) {
        throw new Error('View not previously loaded.');
    }
    // Tratamiento de parámetros
    if (typeof options === 'function') {
        complete = options;
        options = {};
    } else if (!options) {
        options = {};
    }

    var self = this;
    this.load(options, function(err, data) {
        if (err) {
            return (complete && complete(err));
        }
        self.render(Object.extend(options, {
            data: data
        }), function (err, root) {
            if (err) {
                return (complete && complete(err));
            }
            var prevRoot = self.root;
            self.root = root;
            self.root.dataset.viewId = self.uid;
            if (prevRoot.parentNode) {
                prevRoot.parentNode.replaceChild(root, prevRoot);
            }
            self.ready(root, options);
            self.fire('vready');
            if (complete) {
                complete();
            }
        });
    });
};

/**
 * Indica cuando los datos cargados han expirado y se requiere recargar la vista.
 * @return {boolean} Devuelve true si se requiere la recarga.
 */
View.prototype.isExpired = function() {
    return false;
};

/**
 * A implementar por objetos derivados cuando sea necesario realizar algún tipo de inicialización específica, como
 * añadir el tratamiento de eventos, ajustes de dimensiones u otros; después de cargar los datos necesarios (load),
 * generar la representación gráfica (render) y añadir la vista al documento o elemento vinculado a un vista en
 * construcción.
 * @param {HTMLElement} root Elemento raíz de la vista, también accesible mediante <code>this.root</code>.
 * @param {Object} [options] Opciones adicionales especificadas en la inclusión o recarga de la vista.
 */
View.prototype.ready = function(root, options) {
    // NOTE: Implementar por objetos derivados cuando proceda.
};

/**
 * Se extrae la vista del documento.
 */
View.prototype.remove = function() {
    if (this.root && this.root.parentNode) {
        this.saveScroll();
        this.fire('vremove');
        uix.remove(this.root);
        // this.root = null; // NOTE: Si hacemos esto no podríamos recuperar la vista y volverla a añadir al documento
    }
    // NOTE: Para una implementación más específica por objetos derivados no olvidar llamar a la función heredada.
};

/**
 * Destruye la vista.
 */
View.prototype.destroy = function() {
    // NOTE: Implementar por objetos derivados para una implementación más específica de la destrucción de la vista.
    // No olvidar llamar a la función padre.

    // Si sigue añadido al documento o a un elemento de otra vista se elimina.
    this.remove();
    // Se pone a null el elemento raíz.
    this.root = null;
    // Se elimina la instancia de la cache
    View.cache.remove(this.uid);
};

/**
 * Visualiza u oculta la vista.
 * @see uix.toggle
 */
View.prototype.toggle = function(show, options) {
    // Tratamiento de parámetros
    if (typeof show === 'object' && show !== null && !Array.isArray(show)) {
        // ...(options)
        options = show;
        show = options.show;
    } else {
        // ...(show, options)
        if (options == null || typeof options !== 'object' || Array.isArray(options)) {
            options = {};
        } else if (show == null) {
            show = options.show;
        }
    }
    this.fire(show ? 'vbeforeshow' : 'vbeforehide');
    var r = uix.toggle(this.root, show, Object.extend({}, options, {
        done: function() {
            this.fire(show ? 'vaftershow' : 'vafterhide');
            if (options.done) {
                options.done(this);
            }
        }.bind(this)
    }));
    this.fire(show ? 'vshow' : 'vhide');
    return r;
};

/**
 * Reservado para diálogos.
 * @see uix.openDialog
 */
View.prototype.close = function(show, options) {};

/**
 * @return {boolean} Devuelve verdadero si la vista es visible o falso en caso contrario.
 * @see uix.isVisible
 */
View.prototype.isVisible = function() {
    return uix.isVisible(this.root);
};

/**
 * Guarda la posición de scroll de los elementos marcados con la clase 'save-scroll'.
 */
View.prototype.saveScroll = function() {
    var nodes = this.root.querySelectorAll('.save-scroll');
    for (var i = 0; i < nodes.length; i++) {
        nodes[i].dataset.scrollTop = nodes[i].scrollTop;
        nodes[i].dataset.scrollLeft = nodes[i].scrollLeft;
    }
};

/**
 * Recupera la posición de scroll de los elementos marcados con la clase 'save-scroll'.
 */
View.prototype.restoreScroll = function() {
    var nodes = this.root.querySelectorAll('.save-scroll');
    for (var i = 0; i < nodes.length; i++) {
        nodes[i].scrollTop = nodes[i].dataset.scrollTop;
        nodes[i].scrollLeft = nodes[i].dataset.scrollLeft;
    }
};

// Eventos -------------------------------------------------------------------------------------------------------------
/**
 * Añade el manejador de evento al tipo especificado.
 * @param {string} type Tipo de evento.
 * @param {function} handler Función manejadora.
 */
View.prototype.on =
View.prototype.addEventListener = function(type, handler) {
    (this.eventListeners[type] || (this.eventListeners[type] = [])).push(handler);
};

/**
 * Elimina el manejador de evento del tipo especificado.
 * @param {string} type Tipo de evento.
 * @param {function} handler Función manejadora.
 */
View.prototype.off =
View.prototype.removeEventListener = function(type, handler) {
    var list = this.eventListeners[type], i;
    if (list && (i = list.indexOf(handler)) !== -1) {
        list.splice(i, 1);
    }
};

/**
 * Emite el evento especificado.
 * @param {Event|string} event Evento especificado.
 * @return
 */
View.prototype.fire =
View.prototype.dispatchEvent = function(event) {
    if (typeof(event) === 'string') {
        event = new CustomEvent(event);
    }
    var list = this.eventListeners[event.type];
    if (list) {
        event.target = this;
        for (var i = 0; i < list.length; i++) {
            list[i].call(this, event);
        }
    }
};

// =====================================================================================================================
// Include Error
// ---------------------------------------------------------------------------------------------------------------------
/**
 * Error de inclusión de vistas.
 * @param {string} message Mensaje de error.
 * @param {Error|Error[]} [cause] Causa o causas del error.
 * @class
 */
function ViewError(message, cause) {
    this.name = 'ViewError';
    this.message = message;
    this.stack = (new Error()).stack;
    /**
     * Causa o causas del error.
     * @type {Error|Error[]}
     */
    this.cause = cause;
}
ViewError.prototype = Object.create(Error.prototype);
ViewError.prototype.constructor = ViewError;
/**
 * Marco de visualización de vistas y control de navegación.
 * @param {Element} container Elemento contenedor.
 * @param {Object} options Opciones y ajustes de configuración.
 * @param {Viewport~RouteNode[]} options.routes Definición de rutas.
 * @param {boolean} [options.topLevel=false] Indica si el viewport es el de más alto nivel lo que implica realizar la
 * gestión y control del histórico de navegación y la visualización de errores.
 * @param {string} [options.basePath] Ruta base especificada.
 * @param {View} [options.parentView] Vista padre o contenedora del marco.
 * @author terangel
 * @class
 */
function Viewport(container, options) {

    // Opciones por defecto
    var defaults = {
        routes: [],
        topLevel: false,
        basePath: '',
        parentView: null
    };
    options = Object.extend(defaults, options);

    /**
     * Elemento contenedor.
     * @type {Element}
     */
    this.container = container;

    /**
     * Vista contenedora.
     * @type {View}
     */
    this.parentView = options.parentView;

    /**
     * Pila de vistas cargadas.
     * @type {{path: string, view: View, time: number}[]}
     */
    this.views = [];

    /**
     * Referencia a la vista actual.
     * @type {View}
     */
    this.current = null;

    /**
     * Ruta actual, puede incluir parámetros de consulta (query) y fragmento (hash).
     * @type {string}
     */
    this.path = null;

    /**
     * Ruta de referencia anterior. Puede ser especificada en la llamada a la función open.
     * @type {string}
     */
    this.referer = null;

    /**
     * Definición de rutas.
     * @type {Viewport~RouteNode[]}
     */
    this.routes = options.routes;

    /**
     * Indica si el viewport es el de más alto nivel lo que implica realizar la gestión y control del histórico de
     * navegación y la visualización de errores. Por defecto es falso.
     * @type {boolean}
     */
    this.topLevel = options.topLevel;

    /**
     * Ruta base a partir de la cual se extraerán las rutas a vistas.
     * @type {string}
     */
    this.basePath = options.basePath;

    /**
     * Petición actual en proceso.
     * @type {Viewport.Request}
     */
    this.request = null;

    /**
     * Petición de vuelta atrás.
     * @type {{path: string, options: Object}}
     */
    this.backRequest = null;

    /**
     * Guarda la transición con la que la vista actual se visualizó indicando la transición a realizar al volver atrás,
     * si no se especifica otra transición por otro mecanismo.
     * @type {string}
     */
    this.backTransition = null;

    /**
     * Funciones manejadoras de eventos añadidas por tipo.
     * @type {Object.<string, function(event: Object)[]>}
     * @private
     */
    this.eventListeners = {};

    // -----------------------------------------------------------------------------------------------------------------
    if (this.topLevel) {

        // Se añade el tratamiento del evento 'popstate'
        uix.history.on('historypop', function(event) {
            // Se obtiene la ruta de la URL en el navegador incluyendo la cadena de búsqueda o consulta (query) y el
            // fragmento (hash).
            var path = URL.trunc(uix.history.location()),
                state = event.detail && event.detail.state && event.detail.state.data || {};
                options = {
                    history: View.History.NONE
                };
            // Se comprueba si se está volviendo atrás o yendo hacía adelante en el histórico de navegación.
            options.back = event.detail && event.detail.back;
            // Si hay una petición de vuelta atrás se comprueba si la ruta solicitada es la actual.
            if (this.backRequest) {
                if (this.backRequest.path) {
                    // Si se ha especificado ruta en la petición de vuelta atrás, se comparan las rutas excluyendo la
                    // parte del fragmento.
                    if (!this.comparePaths(path, this.backRequest.path, this.backRequest.options)) {
                        // Se elimina la vista asociada a la ruta extraída del histórico.
                        this.removeView(path, true);
                        // Se continua volviendo atrás si hay más entradas en el histórico.
                        if (uix.history.length > 1) {
                            uix.history.back();
                            return;
                        }
                        // Si el histórico de navegación está vacío se sobreescribe la ruta actual.
                        console.log('WARNING: Unable to find path "' + this.backRequest.path + '" in the history.');
                        options.history = View.History.REPLACE;
                    }
                    // Siempre que se especifique una ruta al volver atrás se sobrescribe la actual (incluyendo fragmento).
                    path = this.backRequest.path;
                }
                // Se añaden las opciones adicionales incluidas
                Object.extend(options, this.backRequest.options);
                // Se elimina la petición de vuelta atrás.
                this.backRequest = null;
            }
            // Si la ruta es exactamente igual a la actual, incluyendo los parámetros de consulta y el fragmento, no ha
            // expirado ni se ha solicitado la recarga, acaba el proceso.
            // NOTE: Con esto cubrimos el caso de volver atrás eliminando el fragmento de la URL.
            if (!options.reload && this.current && !this.current.isExpired() &&
                    this.comparePaths(path, this.path, { ignoreQuery: false, ignoreFragment: false })) {
                if (options.complete) {
                    options.complete(null, this.current);
                }
                return;
            }
            if (options.back) {
                // Si se está volviendo atrás y no se ha especificado transición se establece la transición de vuelta
                // atrás actual.
                if (!options.transition) {
                    options.transition = this.backTransition;
                }
                // Si se está volviendo atrás siempre se sobrescribe la transición de vuelta atrás, esté o no definida.
                this.backTransition = state.transition;
            }
            this.open(path, options);
        }.bind(this));
    }
};

/**
 * Abre la ruta especificada.
 * @param {string} path Ruta especificada, puede incluir parámetros de consulta (query) y fragmento (hash).
 * @param {Object|function} [options] Opciones adicionales o función de retorno.
 * @param {boolean} [options.back=false] Indica si se trata de una vuelta atrás en el histórico de navegación.
 * @param {View.History} [options.history=push] Indica que tipo de tratamiento realizar a nivel de histórico de
 * navegación. Por defecto se genera una nueva entrada (push).
 * @param {string} [options.referer] Indica la ruta de referencia anterior.
 * @param {boolean} [options.reload=false] Indica si recargar la vista asociada a la ruta especificada en caso de que se
 * haya cargado previamente.
 * @param {boolean} [options.loader=true] Indica si mostrar o no el indicador de carga.
 * @param {string} [options.transition] Transición a realizar, por defecto ninguna.
 * @param {function(err: Object=, view: View=)} [options.complete] Función de retorno que será llamada al completar la
 * operación.
 * @param {function(err: Object=, view: View=)} [complete] Función de retorno que será llamada al completar la
 * operación, tiene mayor precedencia sobre la propiedad anterior.
 */
Viewport.prototype.open = function(path, options, complete) {
    console.log('[Viewport] Opening ' + path + '...');
    // Tratamiento de parámetros
    if (typeof options === 'function') {
        // (path, complete)
        complete = options;
        options = null;
    }
    options = options || {};
    if (complete) {
        options.complete = complete;
    }
    // Se resuelve la ruta por si fuera relativa
    if (this.topLevel && this.path) {
        path = URL.resolve(path, this.path);
    }
    // Si hay una petición en proceso se cancela
    if (this.request) {
        this.request.cancel();
    }
    // Se construye el nuevo objeto de petición
    this.request = new Viewport.Request(this, path, options);
    // Se inicia la petición
    this.request.start();
};

/**
 * Recarga la ruta actual.
 * @param {Object|function} [options] Opciones adicionales o función de retorno.
 * @param {function(err: Object=, view: View=)} [complete] Función de retorno que será llamada al completar la
 * operación, tiene mayor precedencia sobre la propiedad anterior.
 * @see Viewport.prototype.open
 */
Viewport.prototype.reload = function(options, complete) {
    if (typeof options === 'function') {
        complete = options;
        options = null;
    }
    options = options || {};
    if (complete) {
        options.complete = complete;
    }
    options.reload = true;
    this.open(this.path, options);
};

/**
 * Vuelta atrás en el histórico de navegación. Si se especifica una ruta se vuelve atrás hasta la misma.
 * @param {string|Object|function} [path] Ruta especificada, opciones o función de retorno.
 * @param {Object|function} [options] Opciones adicionales o función de retorno.
 * @param {boolean} [options.reload=false] Indica si recargar la vista.
 * @param {boolean} [options.ignoreQuery=false] Indica si ignorar la parte de los parámetros de consulta.
 * @param {boolean} [options.ignoreFragment=true] Indica si ignorar la parte del fragmento.
 * @param {function(err: Object=, view: View=)} [options.complete] Función de retorno que será llamada al completar la
 * operación.
 * @param {function(err: Object=, view: View=)} [complete] Función de retorno que será llamada al completar la
 * operación, tiene mayor precedencia sobre la propiedad anterior.
 */
Viewport.prototype.back = function(path, options, complete) {
    // Se comprueba que el viewport sea de nivel "top"
    if (!this.topLevel) {
        // NOTE: Aquí podríamos tener una implementación alternativa para cuando el viewport no es de nivel "top", y
        // entonces requerir la especificación de ruta para llamar a la función "open" añadiendo la opción "back".
        return;
    }
    // Tratamiento de parámetros
    if (typeof path === 'function') {
        // (complete)
        complete = path;
        path = options = null;
    } else if (path != null && typeof path === 'object' && !Array.isArray(path)) {
        // (options, complete)
        complete = (typeof options === 'function') ? options : null;
        options = path;
        path = null;
    } else if (typeof options === 'function') {
        // (path, complete)
        complete = options;
        options = null;
    }
    options = options || {};
    if (complete) {
        options.complete = complete;
    }
    if (uix.history.length > 1) {
        // NOTE: Antes estábamos anticipando la visualización del indicador de carga porque en algunos casos parece que
        // la recepción del evento "popstate" después de hacer el history.back(), se retrasa unos instantes.
        // Pero esto no lo podemos hacer porque podemos dejar visualizándose el indicador de carga, como cuando se
        // vuelve atrás sin especificar ruta para cerrar un diálogo.
        // if (options.loader !== false) {
        //     uix.toggleLoader(true);
        // }
        // Se inicia la vuelta atrás en el histórico de navegación
        this.backRequest = {
            path: path,
            options: options
        }
        uix.history.back();
    } else {
        // NOTE: Si no hay entradas en el histórico se abre directamente la ruta reemplazando la actual
        options.history = View.History.REPLACE;
        this.open(path || '/', options);
    }
};

/**
 * Compara dos rutas para determinar si son iguales o equivalentes de cara a la gestión del histórico de navegación,
 * comparando la parte de ruta y opcionalmente los parámetros de búsqueda, sin importar el orden, y el fragmento.
 * @param {?string} path1 Ruta primera.
 * @param {?string} path2 Ruta segunda con la que comparar.
 * @param {Object} [options] Opciones adicionales de comparación.
 * @param {boolean} [options.ignoreQuery=false] Indica si ignorar los parámetros de consulta o no.
 * @param {boolean} [options.ignoreFragment=true] Indica si comparar la parte del fragmento o no. Por defecto se ignora.
 * @return {boolean} Devuelve verdadero si son iguales o equivalentes.
 */
Viewport.prototype.comparePaths = function(path1, path2, options) {
    options = options || {};
    // NOTE: Si no definido o nulo, cualquier otro valor se evalua como booleano.
    ignoreQuery = ('ignoreQuery' in options && options.ignoreQuery !== null) ? !!options.ignoreQuery : false;
    ignoreFragment = ('ignoreFragment' in options&& options.ignoreFragment !== null) ? !!options.ignoreFragment : true;
    path1 = URL.parse(path1, true); path2 = URL.parse(path2, true);
    return (path1.path === path2.path &&
        (ignoreQuery || path1.query.equals(path2.query)) &&
        (ignoreFragment || path1.fragment === path2.fragment));
};

/**
 * Busca los nodos que coincidan con la ruta especificada.
 * @param {string} path Ruta especificada.
 * @param {Viewport~RouteNode[]} [routes] Definición de rutas en donde realizar la búsqueda.
 * @param {Viewport~PathNode[]} [nodes] Si se especifica se insertarán los nodos en el mismo en lugar de crear un nuevo
 * array.
 * @return {Viewport~PathNode[]} Array de nodos resultante.
 * @private
 */
Viewport.prototype.findPathNodes = function(path, routes, nodes) {
    if (routes === undefined) {
        routes = this.routes;
    }
    if (nodes === undefined) {
        nodes = [];
    }
    for (var i = 0, r, m; i < routes.length; i++) {
        r = routes[i];
        if (!r.regexp) {
            if (r.sub = Array.isArray(r.routes) && r.routes.length > 0) {
                // NOTE: Siempre que el nodo defina subrutas evaluaremos parcialmente la expresión de ruta del nodo, no
                // hasta el final de la ruta especificada.
                if (r.end) {
                    // Si se especifica lo contrario generamos un aviso por consola
                    console.log('WARNING: Ignoring invalid end value, the node has subroutes! (' + r.path + ')');
                }
                r.end = false;
            } else if (typeof r.end === 'undefined') {
                // Por defecto evaluaremos la expresión de ruta definida por el nodo hasta el final de la cadena de
                // ruta especificada, añadiendo "$" al final del patrón, cuando el nodo defina una vista.
                r.end = !!r.view;
                // Para variar este comportamiento, por ejemplo cuando delegamos en una vista el procesamiento del
                // resto de la ruta, basta con indicar que el nodo no es final añadiendo la propiedad "end" a "false".
            }
            r.regexp = pathToRegexp(r.path, r.keys = [], {
                end: r.end
            });
        }
        // Se evalua la expresión
        m = r.regexp.exec(path);
        if (m) {
            var n = {
                // Metemos la parte de ruta coincidente con el patrón definido por el nodo
                path: (r.view || r.sub) ? m[0] : ''
                // NOTE: Cuando el nodo no defina ninguna vista ni contenga subrutas, no extraeremos ninguna parte de la
                // cadena de ruta especificada
            };
            if (r.handler) {
                n.handler = r.handler;
            }
            if (r.view) {
                n.view = r.view;
            }
            if (r.queryKeys) {
                n.queryKeys = r.queryKeys;
            }
            n.params = {};
            for (var j = 0; j < r.keys.length; j++) {
                n.params[r.keys[j].name] = m[j + 1];
            }
            n.rest = path.substr(m[0].length);
            nodes.push(n);

            // Si el nodo no es final e incluye subrutas se continua buscando la parte restante de la ruta
            if (!r.end && r.sub) {
                this.findPathNodes(n.rest, r.routes, nodes);
            }
        }
    }
    return nodes;
};

/**
 * Busca una vista cargada asociada a la ruta especificada.
 * @param {string} path Ruta especificada.
 * @return {?View} Devuelve la vista correspondiente o null si no se encuentra.
 * @private
 */
Viewport.prototype.findView = function(path) {
    for (var i = this.views.length - 1; i >= 0; i--) {
        if (this.views[i].path === path) {
            return this.views[i].view;
        }
    }
    return null;
};

/**
 * Añade la vista a la pila asociándola a la ruta o clave de búsqueda especificada. Si la vista ya está añadida se mueve
 * a la cima de la pila actualizando la ruta asociada.
 * @param {string} path Ruta especificada.
 * @param {View} view Vista especificada.
 * @private
 */
Viewport.prototype.pushView = function(path, view) {
    this.removeView(view);
    this.views.push({
        path: path,
        view: view,
        time: Date.now()
    });
};

/**
 * Extrae la vista especificada de la pila.
 * @param {View|string} view Vista especificada o ruta asociada a la misma.
 * @param {boolean} [destroy=false] Indica si destruir la vista.
 * @private
 */
Viewport.prototype.removeView = function(view, destroy) {
    if (typeof(view) === 'string' && (view = this.findView(view)) === null) {
        return;
    }
    for (var i = this.views.length - 1; i >= 0; i--) {
        if (this.views[i].view === view) {
            this.views.splice(i, 1);
            break;
        }
    }
    if (destroy) {
        if (view === this.current) {
            this.current = null;
        }
        view.destroy();
    }
};

/**
 * Evalúa si eliminar instancias del tipo de vista especificado según el valor de la propiedad 'keepInstances' definido
 * en el prototipo de la vista.
 * @param {View} view Vista especificada.
 * @param {boolean} [view.keepInstances] Indica el criterio a seguir para eliminar instancias del tipo de vista.
 * @param {View} [curr] Vista actual a preservar junto con la primera (view) cuando se especifica el parámetro.
 * @private
 */
Viewport.prototype.clearViews = function(view, preserve) {
    var keep;
    switch (view.keepInstances) {
        case '*':
        case View.KEEP_MULTIPLE:
            // NOTE: Si es múltiple no es necesario hacer nada
            return;
        case View.KEEP_SINGLE:
            keep = 1;
            break;
        case View.KEEP_NONE:
            keep = 0;
            break;
        default:
            keep = parseInt(view.keepInstances);
            if (isNaN(keep)) {
                keep = 1;
            }
    }
    for (var i = this.views.length - 1, c = 0; i >= 0; i--) {
        var v =  this.views[i].view;
        if (v instanceof view.constructor) {
            if (++c > keep && (!preserve || preserve.indexOf(v) === -1)) {
                this.views.splice(i, 1);
                v.destroy();
            }
        }
    }
};

/**
 * @return Devuelve true si hay una petición en proceso.
 */
Viewport.prototype.isLoading = function() { // TODO: Lo cambiamos a isRequestPending?
    return !!this.request;
};

/**
 * @param {View} [view] Vista especificada.
 * @return Devuelve true si la vista especificada o si se omite la actual, es de error.
 */
Viewport.prototype.isError = function(view) {
    return !!((view = view || this.current) && view.__error);
};

// Eventos -------------------------------------------------------------------------------------------------------------
/**
 * Añade el manejador de evento al tipo especificado.
 * @param {string} type Tipo de evento.
 * @param {function} handler Función manejadora.
 */
Viewport.prototype.on =
Viewport.prototype.addEventListener = function(type, handler) {
    (this.eventListeners[type] || (this.eventListeners[type] = [])).push(handler);
};

/**
 * Elimina el manejador de evento del tipo especificado.
 * @param {string} type Tipo de evento.
 * @param {function} handler Función manejadora.
 */
Viewport.prototype.off =
Viewport.prototype.removeEventListener = function(type, handler) {
    var list = this.eventListeners[type], i;
    if (list && (i = list.indexOf(handler)) !== -1) {
        list.splice(i, 1);
    }
};

/**
 * Emite el evento especificado.
 * @param {Event|string} event Evento especificado.
 */
Viewport.prototype.fire =
Viewport.prototype.dispatchEvent = function(event) {
    if (typeof(event) === 'string') {
        event = new CustomEvent(event);
    }
    var list = this.eventListeners[event.type];
    if (list) {
        event.target = this;
        for (var i = 0; i < list.length; i++) {
            list[i].call(this, event);
        }
    }
};


// ---------------------------------------------------------------------------------------------------------------------
/**
 * Encapsula los datos y el procesamiento de una petición de carga de una ruta y vista asociada.
 * @param {Viewport} viewport Objeto Viewport al que pertenece la petición.
 * @param {string} path Ruta especificada, puede incluir parámetros de consulta (query) y fragmento (hash).
 * @param {Object} options Opciones adicionales.
 * @param {boolean} [options.back=false] Indica si se trata de una vuelta atrás en el histórico de navegación.
 * @param {View.History} [options.history=View.History.PUSH] Indica que tipo de tratamiento realizar a nivel de
 * histórico de navegación. Por defecto se genera una nueva entrada (push).
 * @param {boolean} [options.reload=false] Indica si recargar la vista asociada a la ruta especificada en caso de que se
 * haya cargado previamente.
 * @param {string} [options.transition] Transición a realizar, por defecto ninguna.
 * @param {function(err: ?Object=)} [options.complete] Función de retorno que será llamada al completar la operación.
 * @constructor
 */
Viewport.Request = function(viewport, path, options) {

    /**
     * Objeto Viewport al que pertenece la petición.
     * @type {Viewport}
     */
    this.viewport = viewport;

    /**
     * Ruta solicitada original, puede incluir parámetros de consulta (query) y fragmento (hash).
     * @type {string}
     */
    this.path = path;

    /**
     * Opciones adicionales.
     * @type {Object}
     */
    this.options = options;

    /**
     * Parte de la ruta procesada hasta el momento.
     * @type {string}
     */
    this.pathPart = '';

    /**
     * Nodos extraídos de la ruta y pendientes de procesar.
     * @type {Viewport~PathNode[]}
     */
    this.pathNodes = null;

    /**
     * Nodo actual en proceso.
     * @type {Viewport~PathNode}
     */
    this.node = null;

    /**
     * Vista en proceso.
     * @type {View}
     */
    this.view = null;

    /**
     * Clave de caché, búsqueda o localización de la vista. Se compone de la ruta (path) y los parámetros de consulta
     * (query) claves especificados en la definición del nodo (queryKeys).
     * @type {string}
     */
    this.viewPath = null;

    /**
     * Objeto de error.
     * @type {*}
     */
    this.error = null;

    /**
     * Transición a realizar.
     * @type {string}
     */
    this.transition = null;

    /**
     * Indica si la petición se ha cancelado.
     * @type {boolean}
     */
    this.cancelled = false;
};

/**
 * Inicia el procesamiento de la petición.
 */
Viewport.Request.prototype.start = function() {
    // Se muestra el indicador de carga
    if (this.viewport.topLevel && this.options.loader !== false) {
        uix.toggleLoader(true);
    }
    // Se parsea la ruta especificada
    var parts = URL.parse(this.path, true);
    this.options.path = parts.path;
    // Se guardan como opciones los parámetros de consulta (query) y la parte del fragmento (hash).
    this.options.query = parts.query;
    if (parts.fragment) {
        this.options.fragment = parts.fragment;
    }
    // Si se ha especificado una ruta base se extrae de la ruta especificada
    // TODO: Realmente es necesario y correcto este tratamiento?, eliminarlo si no procede.
    var path2 = parts.path;
    if (this.viewport.basePath && path2.startsWith(this.viewport.basePath)) {
        path2 = path2.substr(this.viewport.basePath.length);
    }
    // Se buscan los nodos de ruta definidos que coinciden con la ruta anterior
    this.pathNodes = this.viewport.findPathNodes(path2);
    // Se inicia el procesamiento del primer nodo
    this.nextNode();
};

/**
 * Inicia el procesamiento del siguiente nodo.
 */
Viewport.Request.prototype.nextNode = function() {
    // Se comprueba si hay nodos que procesar
    if (this.pathNodes.length === 0) {
        this.showError({
            type: 'not_found',
            message: 'Unable to open: ' + this.path,
            // NOTE: Para simplificar el tratamiento de errores introducimos el código de estado HTTP equivalente.
            status: 404
        });
        return;
    }
    // Se extrae el siguiente nodo.
    this.node = this.pathNodes.shift();
    // Se concatena a la ruta en proceso la parte de la ruta asociada al nodo.
    this.pathPart += this.node.path;
    // Para evitar concatenar dos slash seguidos usar la siguiente expresión:
    // (this.pathPart.endsWith('/') && this.node.path.startsWith('/')) ? this.node.path.substr(1) : this.node.path
    // Se añaden los parámetros extraídos de la ruta definidos por el nodo.
    Object.extend(this.options, this.node.params);
    // Si el nodo define una función manejadora adicional se procesa.
    if (typeof this.node.handler === 'function') {
        var self = this;
        this.node.handler(this, function(err) {
            if (self.cancelled) {
                return;
            }
            if (err) {
                self.showError(err);
                return;
            }
            self.checkView();
        });
    } else {
        this.checkView();
    }
};

/**
 * Continua el proceso comprobando en primer lugar si el nodo actual hace referencia a una vista, realizando la carga
 * o recarga de la misma cuando sea necesario.
 */
Viewport.Request.prototype.checkView = function() {
    // Si el nodo no define vista pasamos al siguiente.
    if (!this.node.view) {
        this.nextNode();
        return;
    }
    // Se compone la clave de búsqueda de la vista compuesta por la ruta y opcionalmente por los parámetros de consulta
    // especificados en la definición del nodo.
    this.viewPath = this.pathPart;
    if (this.node.queryKeys && this.options.query) {
        this.node.queryKeys.forEach(function(name, i) {
            if (name in this.options.query) {
                this.viewPath += ((i > 0) ? '&' : '?') + name + '=' + this.options.query[name];
            }
        }, this);
    }
    // Se comprueba si ya hay una vista cargada asociada a la misma ruta.
    this.view = this.viewport.findView(this.viewPath);
    if (this.view && !this.view.__error) {
        this.appendView(this.view, this.options.reload || this.view.isExpired());
        // TO-DO: Incluir otros criterios de recarga, como pueda ser el tiempo de expiración, para lo cual se puede
        // consultar a la propia vista o llamar directamente a la función de recarga y que sea ella misma quien decida
        // cuando realizar la recarga. Con la opción 'reload' lo que haríamos es forzar la recarga en cualquier caso.
    } else {
        // Se carga la vista.
        this.appendView(this.node.view);
    }
};

/**
 * Continua el proceso cargando o recargando la vista especificada y añadiéndola al contenedor cuando sea necesario.
 * @param {{View|string}} view Vista especificada.
 * @param {boolean} [reload] Indica si recargar la vista especificada.
 */
Viewport.Request.prototype.appendView = function(view, reload) {
    if (typeof view === 'string') {
        var name = view;
        // Se carga la vista
        try {
            view = View.create(name, Object.extend(this.options, {
                parentView: this.viewport.parentView
            }));
        } catch (err) {
            console.log('Unable to create view "' + name + '" (' + this.viewPath + '): ' + err);
            this.showError(err);
            return;
        }
        if (this.error) {
            // Si hay un error se marca la vista como error
            view.__error = true;
        }
    }
    // Se comprueba si se ha cancelado la petición en la creación, quizás por la apertura de otra ruta.
    if (this.cancelled) {
        return;
    }

    var self = this;
    // Guardamos la referencia a la vista
    this.view = view;
    // Se recarga la vista cuando corresponda
    if (reload) {
        setTimeout(function() {
            // TODO: Evaluar como punto de cancelación!
            view.reload(self.options, function(err) {
                // TODO: Evaluar como punto de cancelación!
                if (err) {
                    console.log('Unable to reload view "' + view.__view_name + '" (' + self.viewPath + '): ' + err);
                    self.showError(err);
                    return;
                }
                self.appendView(view)
            });
            // NOTE: Se retrasa la recarga de la vista un tiempo mínimo para no detener la secuencia actual
        }, 10);
        return;
    }
    // Se comprueba si se trata de la vista actual
    if (view === this.viewport.current) {
        this.stepInto();
    } else {
        // Se añade la vista al contenedor
        setTimeout(function() {
            // TODO: Evaluar como punto de cancelación!
            view.include(self.viewport.container, Object.extend(self.options, {
                hide: true,
                // NOTE: Sin "display: none" en determinadas circunstancias, nada más incluir la vista, no se realiza la
                // transición de visualización.
                style: {
                    display: 'none'
                }
            }), function(err) {
                // TODO: Evaluar como punto de cancelación!
                if (err) {
                    console.log('Unable to append view "' + view.__view_name + '" (' + self.viewPath + '): ' + err);
                    self.showError(err);
                    return;
                }
                // Se continua el proceso
                self.stepInto();
            });
            // NOTE: Se retrasa la inclusión de la vista un tiempo mínimo para no detener la secuencia actual en el caso
            // de que la vista no requiera carga de datos asíncrona y su renderización inicial sea pesada.
        }, 10);
    }
};

/**
 * Comprueba si la vista cargada define la función "open" para que procese el resto de la ruta.
 */
Viewport.Request.prototype.stepInto = function() {
    // Se comprueba si la vista implementa la función 'open' para continuar procesando la rutaopen
    if (typeof this.view.open === 'function') {
        var self = this;
        this.view.open(this.node.rest, Object.extend({}, this.options), function(err) {
            if (self.cancelled) {
                self.view.destroy();
                return;
            }
            if (err) {
                // TODO: Traceamos el error o confiamos que lo haga la subvista?
                self.showError(err);
                return;
            }
            self.pushView();
        });
    } else {
        this.pushView();
    }
};

/**
 * Añade la vista a la pila, actualiza la ruta actual, evalua la transición a realizar y actualiza el histórico de
 * navegación.
 */
Viewport.Request.prototype.pushView = function() {
    // Se actualiza la ruta actual.
    var vpath = this.viewport.path;
    this.viewport.path = this.path;
    // Si se ha especificado ruta de referencia se actualiza.
    if (this.options.referer) {
        this.viewport.referer = this.options.referer;
    }
    // Se comprueba si se trata de la vista actual.
    if (this.view !== this.viewport.current) {
        // Se evalua la transición a realizar
        if (this.options.transition !== undefined) {
            this.transition = this.options.transition;
        } else {
            // NOTE: Si no se ha especificado transición en las opciones se obtiene de las clases de estilo añadidas en
            // la raíz de la vista.
            var curr = this.options.back ? this.viewport.current : this.view;
            this.transition = curr ? (curr.transition || curr.root.dataset.transition || null) : null;
        }
        // Si no se trata de una vuelta atrás, se guarda la transición para uso posterior.
        if (!this.options.back) {
            this.viewport.backTransition = this.transition;
        }
    }
    // Se realiza la gestión del histórico de navegación.
    if (this.viewport.topLevel && this.options.history !== View.History.NONE) {
        if (this.options.history === View.History.REPLACE) {
            uix.history.replace(this.path, {
                transition: this.transition
            });
        } else if (!this.viewport.comparePaths(this.path, vpath)) {
            // NOTE: No generamos entrada en el histórico cuando la ruta cargada con anterioridad sea igual a la
            // especificada, aunque la localización por navegación interna haya cambiado desde entonces.
            // * Tenemos muchas dudas al respecto, quizás deberíamos comparar con la ruta identificativa de
            // la vista (viewPath), la cual puede incluir o no parámetros según su especificación en la definición de
            // rutas.
            // * También nos cuestionamos si incluir en la comparación la parte del fragmento.
            uix.history.push(this.path, {
                transition: this.transition
            });
        }
    }
    // Si continua el proceso
    if (this.view !== this.viewport.current) {
        this.switchView();
    } else {
        this.done();
    }
};

/**
 * Continua el proceso realizando el intercambio de vistas.
 */
Viewport.Request.prototype.switchView = function() {
    // En caso contrario se actualiza la referencia a la vista actual
    var self = this;
    var curr = this.viewport.current;
    // Se añade a la pila o se mueve a la cima de la misma
    this.viewport.pushView(this.viewPath, this.view);
    // Se cambia la referencia actual a la vista
    this.viewport.current = this.view; // TODO: Evaluar si hacerlo dentro del método anterior
    // Se realiza la transición entre las vistas
    this.view.toggle(true, {
        transition: this.transition,
        reverse: this.options.back,
        done: function() {
            // Se comprueba si eliminar de la pila otras instancias del mismo tipo de vista
            self.viewport.clearViews(self.view, [self.view, curr]);
        }
    })
    if (curr) {
        // Se oculta la vista anterior
        curr.toggle(false, {
            transition: this.transition,
            reverse: !this.options.back,
            done: function() {
                // Se extrae la vista del documento
                curr.remove();
                // Si es una vista de error, estamos volviendo atrás o estamos reemplazando la ruta actual, se extrae de
                // la pila y se destruye
                if (curr.__error || self.options.back || self.options.history === View.History.REPLACE) {
                    // TODO: Si estamos reemplazando un ruta con fragmento porque hemos abierto un diálogo, no
                    //  deberíamos eliminar la vista actual.
                    self.viewport.removeView(curr, true);
                }
                // Se comprueba si eliminar instancias del mismo tipo de vista
                self.viewport.clearViews(curr, [self.view]);
            }
        });
    }
    // Se finaliza el proceso
    this.done();
};

/**
 * En caso de error carga la vista de error.
 * @param {*} [err] Error especificado.
 */
Viewport.Request.prototype.showError = function(err) {
    // Si ya hay un error acaba el proceso
    if (this.error) {
        this.done();
        return;
    }
    // Se guarda el error
    this.error = err;
    // Si tenemos la referencia a una vista se extrae de la pila y se destruye
    if (this.view) {
        this.viewport.removeView(this.view, true);
        this.view = null;
    }
    // Se carga y se muestra la vista de error, si se ha definido
    if (View.exists('error')) {
        // Se añade el error a las opciones
        this.options.error = err;
        // Se realiza la carga de la vista de error
        this.appendView('error')
    } else {
        console.log('Error view is not defined: ' + err);
        this.done();
    }
};

/**
 * Finaliza el proceso.
 */
Viewport.Request.prototype.done = function() {
    if (this.viewport.topLevel) { // TODO: Evaluar si meter o no la comprobación: && this.options.loader !== false
        // Se oculta el indicador de carga
        uix.toggleLoader(false);
    }
    // Se genera un evento.
    this.viewport.fire('vopen');
    // Se llama a la función de retorno.
    // TODO: Notificamos un error si la petición se ha cancelado???
    if (this.options.complete) {
        this.options.complete(this.error, this.view);
    }
    // Evento de seguimiento.
    if (this.viewport.topLevel) {
        uix.track('view_open', this.view);
    }
    // Se elimina del viewport.
    if (this.viewport.request === this) {
        this.viewport.request = null;
    }
};

/**
 * Cancela la petición.
 */
Viewport.Request.prototype.cancel = function() {
    this.cancelled = true;
};

/**
 * Busca el nombre de parámetro especificado comprobando si está definido como clave en la identificación o localización
 * de la vista en caché.
 * TODO: De momento solo buscamos en el último nodo de ruta extraído pero quizás deberíamos buscar en todos.
 * @param {string} name Nombre de parámetro especificado.
 * @return {boolean} Devuelve verdadero si es clave.
 */
Viewport.Request.prototype.isQueryKey = function(name) {
    if (this.pathNodes.length > 0) {
        var no = this.pathNodes[this.pathNodes.length - 1];
        return (no.queryKeys && no.queryKeys.indexOf(name) !== -1);
    }
    return false;
};

// ---------------------------------------------------------------------------------------------------------------------
/**
 * Posibles acciones a nivel de histórico de navegación a realizar en la apertura de rutas. Desde no realizar ninguna
 * acción (none), hasta añadir una nueva entrada (push) o reemplazar la actual (replace).
 * @enum {string}
 */
View.History = {
    NONE    : 'none',
    PUSH    : 'push',
    REPLACE : 'replace'
};

// ---------------------------------------------------------------------------------------------------------------------
// Posibles valores de la propiedad "keepInstances" de las instancias de View, que indica el número de instancias de una
// vista que se pueden mantener cargadas en memoria simultáneamente:
/**
 * Indica que no se debe mantener ninguna instancia de la vista cargada en memoria.
 * @type {string}
 * @constant
 */
View.KEEP_NONE = 'none';

/**
 * Indica que se debe mantener una única instancia de la vista cargada en memoria.
 * @type {string}
 * @constant
 */
View.KEEP_SINGLE = 'single';

/**
 * Indica que se pueden mantener múltiples instancias de la vista cargadas en memoria.
 * @type {string}
 * @constant
 */
View.KEEP_MULTIPLE = 'multiple';

// Se añade la propiedad al prototipo de View con el valor por defecto:
/**
 * Número de instancias de la vista que se pueden mantener cargadas en memoria simultáneamente.
 * @type {string|number}
 */
View.prototype.keepInstances = View.KEEP_SINGLE;

// ---------------------------------------------------------------------------------------------------------------------
/**
 * Definición de un nodo de ruta.
 * @typedef {Object} Viewport~RouteNode
 * @property {string} path Ruta parcial del nodo.
 * @property {string|function(new:View, Object=)} [view] Nombre de la vista o constructor del manejador.
 * @property {string[]} [queryKeys] Nombre de los parámetros de consulta (query) claves asociados a la vista y que serán
 * incluidos en la clave de caché, búsqueda o localización de la vista en la pila de vistas cargadas.
 * @property {function(request: Viewport.Request, callback: function)} [handler] Función manejadora adicional.
 * @property {boolean} [end] Indica si el patrón de ruta definido por el nodo debe ser evaluado hasta el final de la
 * cadena ruta especidada o no.
 */

/**
 * Información temporal extraída del procesamiento de la definición de un nodo de ruta.
 * @typedef {Object} Viewport~PathNode
 * @property {string} path Parte de la ruta coincidente con el patrón del nodo.
 * @property {Object.<string,string>} [params] Parámetros extraídos de la ruta.
 * @property {string} [rest] Parte restante de la ruta sin procesar.
 * @property {string|function(new:View, Object=)} [view] Nombre de la vista o constructor del manejador asociado.
 * @property {string[]} [queryKeys] Nombre de los parámetros de consulta (query) claves asociados a la vista y que serán
 * incluidos en la clave de caché, búsqueda o localización de la vista en la pila de vistas cargadas.
 * @property {function(request: Viewport.Request, callback: function)} [handler] Función manejadora adicional.
 */
/*
 * @file track.js
 * @author angel.teran
 */
(function() {
    /**
     * Referencia al plugin de Firebase.
     * @type {Object}
     */
    var firebase = window.cordova && window.cordova.plugins.firebase;

    // TODO: Si no estamos en Cordova o no está el plugin podríamos desde aquí realizar la carga de la librería de Analytics (gtag.js)

    /**
     * Acorta la cadena o el valor de las propiedades del objeto especificado a un número determinado de caracteres.
     * @param {string|Object} value Cadena valor u objeto de parámetros especificado.
     * @return {string|Object} Devuelve la cadena resultante o un nuevo objeto con el valor modificado de las
     * propiedades del objeto original especificado.
     */
    var trunc = function(value) {
        if (typeof value === 'undefined' || value === null) {
            return value;
        }
        if (typeof value === 'object') {
            var obj = {};
            for (var key in value) {
                if (value.hasOwnProperty(key)) {
                    obj[key] = trunc(value[key]);
                }
            }
            return obj;
        }
        if (typeof value === 'string' && value.length > 100) {
            return value.substr(0, 99) + '…';
        }
        return value;
    };

    /**
     * Emite un evento de seguimiento.
     * @param {string} event Nombre de evento especificado.
     * @param {Object|View} [params] Parámetros adicionales o referencia a una vista para el evento 'view_open'.
     */
    uix.track = function(event, params) {
        if (event === 'view_open' && params instanceof View) {
            var view = params;
            if (!view.trackPath) {
                return;
            }
            params = {
                view_path: (typeof view.trackPath === 'function') ? view.trackPath.call() : view.trackPath,
                view_location: URL.trunc(uix.history.location())
            };
        }
        if (firebase) {
            if (event === 'view_open') {
                firebase.analytics.setCurrentScreen(trunc(params.view_path));
            } else {
                firebase.analytics.logEvent(event, trunc(params));
            }
        } else {
            // TODO: Implementar con gtag.js...
            console.log('track("' + event + '", ' + (params && JSON.stringify(params)) + ')');
        }
    };

    /**
     * Establece el identificador de usuario especificado.
     * @param {string} userId Identificador de usuario.
     */
    uix.track.setUserId = function(userId) {
        if (firebase) {
            firebase.analytics.setUserId(userId);
        } else {
            // TODO: Implementar con gtag.js...
            console.log('setUserId("' + userId + '")');
        }
    };

})();