/**
 * taps.js
 */
